package cineman.model;

import java.sql.Date;

public class Movie8 {

    private String movieId;
    private String managerId;
    private String movieName;
    private String genre;
    private int duration;
    private String description;
    private Date startDate;
    private Date endDate;
    private String status;

    public Movie8() {
    }

    public Movie8(String movieId, String managerId, String movieName,
                  String genre, int duration, String description,
                  Date startDate, Date endDate, String status) {

        this.movieId = movieId;
        this.managerId = managerId;
        this.movieName = movieName;
        this.genre = genre;
        this.duration = duration;
        this.description = description;
        this.startDate = startDate;
        this.endDate = endDate;
        this.status = status;
    }

    public String getMovieId() {
        return movieId;
    }

    public void setMovieId(String movieId) {
        this.movieId = movieId;
    }

    public String getManagerId() {
        return managerId;
    }

    public void setManagerId(String managerId) {
        this.managerId = managerId;
    }

    public String getMovieName() {
        return movieName;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}