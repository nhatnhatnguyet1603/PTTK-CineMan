
package cineman.model;

import java.sql.Date;

public class MembershipCard8 {

    private String membershipCardId;
    private String customerId;
    private String membershipCode;
    private String membershipLevel;
    private Date issueDate;
    private Date expiryDate;
    private String status;

    public MembershipCard8() {}

    public String getMembershipCardId() { return membershipCardId; }
    public void setMembershipCardId(String membershipCardId) {
        this.membershipCardId = membershipCardId;
    }

    public String getCustomerId() { return customerId; }
    public void setCustomerId(String customerId) { this.customerId = customerId; }

    public String getMembershipCode() { return membershipCode; }
    public void setMembershipCode(String membershipCode) {
        this.membershipCode = membershipCode;
    }

    public String getMembershipLevel() { return membershipLevel; }
    public void setMembershipLevel(String membershipLevel) {
        this.membershipLevel = membershipLevel;
    }

    public Date getIssueDate() { return issueDate; }
    public void setIssueDate(Date issueDate) { this.issueDate = issueDate; }

    public Date getExpiryDate() { return expiryDate; }
    public void setExpiryDate(Date expiryDate) { this.expiryDate = expiryDate; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
