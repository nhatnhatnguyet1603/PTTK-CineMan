
package cineman.controller;

import cineman.dao.MovieDAO8;
import cineman.model.Movie8;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;

@WebServlet("/AddMovieController8")
public class AddMovieController8 extends HttpServlet {

    private MovieDAO8 movieDAO;

    @Override
    public void init() {
        movieDAO = new MovieDAO8();
    }

    // Kiểm tra tính hợp lệ của thông tin phim
    public boolean validateMovieInformation(Movie8 movie) {

        if (movie == null) {
            return false;
        }

        if (movie.getMovieName() == null
                || movie.getMovieName().trim().isEmpty()) {
            return false;
        }

        if (movie.getGenre() == null
                || movie.getGenre().trim().isEmpty()) {
            return false;
        }

        if (movie.getDuration() <= 0) {
            return false;
        }

        if (movie.getDescription() == null
                || movie.getDescription().trim().isEmpty()) {
            return false;
        }

        if (movie.getStartDate() == null
                || movie.getEndDate() == null) {
            return false;
        }

        // Ngày kết thúc phải sau ngày bắt đầu
        return movie.getEndDate().after(movie.getStartDate());
    }

    // Xác định trạng thái phim dựa trên thời gian chiếu
    private String calculateMovieStatus(Date startDate, Date endDate) {

        LocalDate today = LocalDate.now();

        LocalDate start = startDate.toLocalDate();
        LocalDate end = endDate.toLocalDate();

        if (today.isBefore(start)) {
            return "UPCOMING";
        }

        if (today.isAfter(end)) {
            return "INACTIVE";
        }

        return "ACTIVE";
    }

    // Yêu cầu DAO thêm phim vào cơ sở dữ liệu
    public boolean addMovie(Movie8 movie) {
        return movieDAO.addMovie(movie);
    }

    // Lấy danh sách phim đang hoạt động
    public List<Movie8> getMovieList() {
         return movieDAO.getAllMovieList();
    }

    // Kiểm tra tài khoản đang đăng nhập có phải quản lý hay không
    private boolean isManagerLoggedIn(HttpSession session) {

        if (session == null) {
            return false;
        }

        String userRole = (String) session.getAttribute("userRole");

        return "manager".equalsIgnoreCase(userRole)
                && getManagerId(session) != null;
    }

    // Lấy mã nhân viên quản lý từ session đăng nhập
    private String getManagerId(HttpSession session) {

        Object employeeId = session.getAttribute("employeeId");

        if (employeeId == null) {
            employeeId = session.getAttribute("managerId");
        }

        return employeeId == null
                ? null
                : employeeId.toString();
    }

    // Hiển thị giao diện thêm phim
    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession(false);

        if (!isManagerLoggedIn(session)) {
            response.sendRedirect(
                    request.getContextPath() + "/login.jsp"
            );
            return;
        }

        request.setAttribute("movieList", getMovieList());

        request.getRequestDispatcher(
                "/WEB-INF/views/admin/add-movie.jsp"
        ).forward(request, response);
    }

    // Tiếp nhận và xử lý yêu cầu thêm phim
    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession(false);

        if (!isManagerLoggedIn(session)) {
            response.sendRedirect(
                    request.getContextPath() + "/login.jsp"
            );
            return;
        }

        String managerId = getManagerId(session);

        // Lấy dữ liệu từ biểu mẫu
        String movieName = request.getParameter("inMovieName");
        String genre = request.getParameter("inGenre");
        String durationInput = request.getParameter("inDuration");
        String description = request.getParameter("inDescription");
        String startDateInput = request.getParameter("inStartDate");
        String endDateInput = request.getParameter("inEndDate");

        // Tạo đối tượng phim từ dữ liệu nhận được
        Movie8 movie = new Movie8();

        movie.setManagerId(managerId);
        movie.setMovieName(
                movieName == null ? "" : movieName.trim()
        );
        movie.setGenre(
                genre == null ? "" : genre.trim()
        );
        movie.setDescription(
                description == null ? "" : description.trim()
        );

        String errorMessage = null;

        // Chuyển đổi thời lượng và ngày tháng
        try {

            if (durationInput == null || durationInput.trim().isEmpty()
                    || startDateInput == null || startDateInput.trim().isEmpty()
                    || endDateInput == null || endDateInput.trim().isEmpty()) {

                throw new IllegalArgumentException();
            }

            int duration = Integer.parseInt(durationInput.trim());

            LocalDate startDate = LocalDate.parse(startDateInput);
            LocalDate endDate = LocalDate.parse(endDateInput);

            movie.setDuration(duration);
            movie.setStartDate(Date.valueOf(startDate));
            movie.setEndDate(Date.valueOf(endDate));

        } catch (DateTimeParseException | IllegalArgumentException e) {

            errorMessage = "Thời lượng hoặc ngày tháng không hợp lệ.";
        }

        // Kiểm tra thông tin phim trước khi xử lý tiếp
        if (errorMessage == null
                && !validateMovieInformation(movie)) {

            errorMessage = "Vui lòng kiểm tra lại thông tin phim. "
                    + "Tên phim, thể loại và mô tả không được để trống; "
                    + "thời lượng phải lớn hơn 0 và ngày kết thúc "
                    + "phải sau ngày bắt đầu.";
        }

        // Chỉ tính trạng thái khi ngày tháng hợp lệ
        if (errorMessage == null) {
            movie.setStatus(
                    calculateMovieStatus(
                            movie.getStartDate(),
                            movie.getEndDate()
                    )
            );
        }

        // Kiểm tra tên phim đã tồn tại hay chưa
      // Kiểm tra tên phim đã tồn tại hay chưa
if (errorMessage == null) {

    try {
        if (movieDAO.isMovieExists(movie.getMovieName())) {
            errorMessage = "Tên phim đã tồn tại trong hệ thống.";
        }
    } catch (java.sql.SQLException e) {
        errorMessage = "Không thể kiểm tra dữ liệu phim. Vui lòng thử lại.";
        e.printStackTrace();
    }
}

        // Nếu dữ liệu không hợp lệ, trả kết quả về giao diện
        if (errorMessage != null) {

            request.setAttribute("outResult", errorMessage);
            request.setAttribute("resultType", "danger");
            request.setAttribute("movie", movie);
            request.setAttribute("movieList", getMovieList());

            request.getRequestDispatcher(
                    "/WEB-INF/views/admin/add-movie.jsp"
            ).forward(request, response);

            return;
        }

        // Thực hiện thêm phim vào cơ sở dữ liệu
        boolean addResult = addMovie(movie);

        if (addResult) {

            request.setAttribute(
                    "outResult",
                    "Thêm phim thành công!"
            );

            request.setAttribute("resultType", "success");

        } else {

            request.setAttribute(
                    "outResult",
                    "Thêm phim thất bại. Vui lòng kiểm tra lại dữ liệu."
            );

            request.setAttribute("resultType", "danger");
            request.setAttribute("movie", movie);
        }

        // Cập nhật danh sách phim sau khi xử lý
        request.setAttribute("movieList", getMovieList());

        request.getRequestDispatcher(
                "/WEB-INF/views/admin/add-movie.jsp"
        ).forward(request, response);
    }
}
