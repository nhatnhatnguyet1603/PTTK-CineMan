
package cineman.controller;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/CustomerMainMenu8")
public class CustomerMainMenuController8 extends HttpServlet {

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null
                || !"customer".equalsIgnoreCase(
                        String.valueOf(session.getAttribute("userRole")))
                || session.getAttribute("customerId") == null) {

            response.sendRedirect(
                    request.getContextPath() + "/login.jsp?role=customer"
            );
            return;
        }

        request.getRequestDispatcher(
                "/WEB-INF/views/customer/customer-main-menu.jsp"
        ).forward(request, response);
    }
}
