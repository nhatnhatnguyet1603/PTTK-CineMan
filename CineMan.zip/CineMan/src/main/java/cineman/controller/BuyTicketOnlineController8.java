
package cineman.controller;

import cineman.dao.*;
import cineman.model.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

@WebServlet("/BuyTicketOnlineController8")
public class BuyTicketOnlineController8 extends HttpServlet {

    private final MovieDAO8 movieDAO = new MovieDAO8();
    private final ShowtimeDAO8 showtimeDAO = new ShowtimeDAO8();
    private final SeatDAO8 seatDAO = new SeatDAO8();

    private final MembershipCardDAO8 membershipDAO =
            new MembershipCardDAO8();

    private final BookingDAO8 bookingDAO = new BookingDAO8();
    private final PaymentDAO8 paymentDAO = new PaymentDAO8();
    private final TicketDAO8 ticketDAO = new TicketDAO8();
    private final InvoiceDAO8 invoiceDAO = new InvoiceDAO8();

    // Muc giam gia thanh vien: 5%
    private static final BigDecimal DISCOUNT_RATE =
            new BigDecimal("0.05");

    // =====================================================
    // KIEM TRA CUSTOMER DANG DANG NHAP
    // =====================================================

    private boolean isCustomerLoggedIn(HttpSession session) {

        return session != null
                && "customer".equalsIgnoreCase(
                        String.valueOf(session.getAttribute("userRole")))
                && session.getAttribute("customerId") != null;
    }

    private String getCustomerId(HttpSession session) {
        return String.valueOf(session.getAttribute("customerId"));
    }

    // =====================================================
    // FORWARD SANG JSP
    // =====================================================

    private void forwardToView(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        request.getRequestDispatcher(
                "/WEB-INF/views/customer/buy-ticket-online.jsp"
        ).forward(request, response);
    }

    // =====================================================
    // TAO MA DINH DANH
    // =====================================================

    private String generateId(String prefix) {

        return prefix + UUID.randomUUID()
                .toString()
                .replace("-", "")
                .substring(0, 17)
                .toUpperCase();
    }

    // =====================================================
    // 1. LOAD DANH SACH PHIM
    // =====================================================

    public List<Movie8> loadMovieList() {
        return movieDAO.getMovieList();
    }

    // =====================================================
    // 2. LOAD SUAT CHIEU THEO PHIM
    // =====================================================

    public List<Showtime8> selectMovie(String movieId) {
        return showtimeDAO.getShowtimeList(movieId);
    }

    // =====================================================
    // 3. LOAD GHE CON TRONG
    // =====================================================

    public List<Seat8> loadAvailableSeats(String showtimeId) {
        return seatDAO.getAvailableSeats(showtimeId);
    }

    // =====================================================
    // 4. KIEM TRA MA THANH VIEN
    // =====================================================

    public boolean validateMembershipCode(
            String membershipCode,
            HttpSession session) {

        if (membershipCode == null
                || membershipCode.trim().isEmpty()) {
            return false;
        }

        if (!isCustomerLoggedIn(session)) {
            return false;
        }

        MembershipCard8 card =
                membershipDAO.validateMembershipCode(
                        membershipCode.trim(),
                        getCustomerId(session)
                );

        return card != null;
    }

    // =====================================================
    // 5. TINH TONG TIEN GOC
    // =====================================================

    public BigDecimal calculateTotalAmount(
            List<Seat8> selectedSeats,
            BigDecimal ticketPrice) {

        BigDecimal total = ticketPrice.multiply(
                BigDecimal.valueOf(selectedSeats.size())
        );

        return total.setScale(2, RoundingMode.HALF_UP);
    }

    // =====================================================
    // 6. TAO BOOKING
    // =====================================================

    public boolean createBooking(Booking8 booking) {
        return bookingDAO.createBooking(booking);
    }

    // =====================================================
    // 7. THANH TOAN
    // =====================================================

    public boolean makePayment(Payment8 payment) {

        // Mo phong thanh toan thanh cong
        payment.setPaymentTime(LocalDateTime.now());
        payment.setPaymentStatus("SUCCESS");

        return paymentDAO.savePayment(payment);
    }

    // =====================================================
    // 8. TAO VE
    // =====================================================

    public boolean createTicket(Ticket8 ticket) {
        return ticketDAO.createTicket(ticket);
    }

    // =====================================================
    // 9. TAO HOA DON
    // =====================================================

    public boolean createInvoice(Invoice8 invoice) {
        return invoiceDAO.createInvoice(invoice);
    }

    // =====================================================
    // LOAD LAI DU LIEU FORM KHI CO LOI
    // =====================================================

    private void reloadFormData(
            HttpServletRequest request,
            String movieId,
            String showtimeId) {

        request.setAttribute("movieList", loadMovieList());

        if (movieId != null && !movieId.isBlank()) {

            request.setAttribute("selectedMovieId", movieId);

            request.setAttribute(
                    "showtimeList",
                    selectMovie(movieId)
            );
        }

        if (showtimeId != null && !showtimeId.isBlank()) {

            request.setAttribute("selectedShowtimeId", showtimeId);

            request.setAttribute(
                    "seatList",
                    loadAvailableSeats(showtimeId)
            );
        }
    }

    // =====================================================
    // DO GET
    // =====================================================

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (!isCustomerLoggedIn(session)) {

            response.sendRedirect(
                    request.getContextPath()
                    + "/login.jsp?role=customer"
            );

            return;
        }

        String action = request.getParameter("action");

        if ("showtimes".equals(action)) {

            String movieId = request.getParameter("movieId");

            request.setAttribute("selectedMovieId", movieId);

            request.setAttribute(
                    "showtimeList",
                    selectMovie(movieId)
            );

        } else if ("seats".equals(action)) {

            String movieId = request.getParameter("movieId");
            String showtimeId = request.getParameter("showtimeId");

            request.setAttribute("selectedMovieId", movieId);
            request.setAttribute("selectedShowtimeId", showtimeId);

            request.setAttribute(
                    "showtimeList",
                    selectMovie(movieId)
            );

            request.setAttribute(
                    "seatList",
                    loadAvailableSeats(showtimeId)
            );
        }

        request.setAttribute("movieList", loadMovieList());

        forwardToView(request, response);
    }

    // =====================================================
    // DO POST
    // =====================================================

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (!isCustomerLoggedIn(session)) {

            response.sendRedirect(
                    request.getContextPath()
                    + "/login.jsp?role=customer"
            );

            return;
        }

        request.setCharacterEncoding("UTF-8");

        String action = request.getParameter("action");

        // -------------------------------------------------
        // KIEM TRA MA THANH VIEN
        // -------------------------------------------------

        if ("validateMembership".equals(action)) {

            String membershipCode =
                    request.getParameter("membershipCode");

            boolean valid = false;

            try {

                if (membershipCode != null
                        && !membershipCode.trim().isEmpty()) {

                    valid = validateMembershipCode(
                            membershipCode,
                            session
                    );
                }

                request.setAttribute("membershipValid", valid);

                request.setAttribute(
                        "membershipMessage",
                        valid
                                ? "Ma thanh vien hop le. Ban duoc giam 5%."
                                : "Ma thanh vien khong hop le, da het han hoac khong thuoc tai khoan cua ban."
                );

            } catch (Exception e) {

                e.printStackTrace();

                request.setAttribute("membershipValid", false);

                request.setAttribute(
                        "membershipMessage",
                        "Khong the kiem tra ma thanh vien. Vui long thu lai."
                );
            }

            // Giu lai phim va suat chieu da chon
            String movieId = request.getParameter("movieId");
            String showtimeId = request.getParameter("showtimeId");

            reloadFormData(request, movieId, showtimeId);

            forwardToView(request, response);
            return;
        }

        // -------------------------------------------------
        // XAC NHAN MUA VE
        // -------------------------------------------------

        if ("confirmPurchase".equals(action)) {

            processPurchase(request, response, session);
            return;
        }

        response.sendRedirect(
                request.getContextPath()
                + "/BuyTicketOnlineController8"
        );
    }

    // =====================================================
    // XU LY MUA VE TRUC TUYEN
    // =====================================================

    private void processPurchase(
            HttpServletRequest request,
            HttpServletResponse response,
            HttpSession session)
            throws ServletException, IOException {

        String movieId = request.getParameter("movieId");
        String showtimeId = request.getParameter("showtimeId");

        try {

            String[] selectedSeatIds =
                    request.getParameterValues("seatIds");

            String membershipCode =
                    request.getParameter("membershipCode");

            String paymentMethod =
                    request.getParameter("paymentMethod");

            // -------------------------------------------------
            // BUOC 1: KIEM TRA DU LIEU DAU VAO
            // -------------------------------------------------

            if (movieId == null || movieId.isBlank()
                    || showtimeId == null || showtimeId.isBlank()
                    || selectedSeatIds == null
                    || selectedSeatIds.length == 0) {

                throw new IllegalArgumentException(
                        "Vui long chon phim, suat chieu va ghe."
                );
            }

            if (paymentMethod == null
                    || !(paymentMethod.equals("CASH")
                    || paymentMethod.equals("BANKING"))) {

                throw new IllegalArgumentException(
                        "Phuong thuc thanh toan khong hop le."
                );
            }

            // Kiem tra ghe trung trong du lieu gui len
            Set<String> uniqueSeatIds = new HashSet<>();

            for (String seatId : selectedSeatIds) {

                if (seatId == null
                        || seatId.isBlank()
                        || !uniqueSeatIds.add(seatId)) {

                    throw new IllegalArgumentException(
                            "Danh sach ghe khong hop le hoac bi trung."
                    );
                }
            }

            // -------------------------------------------------
            // BUOC 2: KIEM TRA PHIM
            // -------------------------------------------------

            Movie8 selectedMovie = null;

            for (Movie8 movie : loadMovieList()) {

                if (movie.getMovieId().equals(movieId)) {

                    selectedMovie = movie;
                    break;
                }
            }

            if (selectedMovie == null) {

                throw new IllegalArgumentException(
                        "Phim khong ton tai hoac khong con hoat dong."
                );
            }

            // -------------------------------------------------
            // BUOC 3: KIEM TRA SUAT CHIEU
            // -------------------------------------------------

            Showtime8 selectedShowtime = null;

            for (Showtime8 showtime : selectMovie(movieId)) {

                if (showtime.getShowtimeId().equals(showtimeId)) {

                    selectedShowtime = showtime;
                    break;
                }
            }

            if (selectedShowtime == null) {

                throw new IllegalArgumentException(
                        "Suat chieu khong hop le."
                );
            }

            // -------------------------------------------------
            // BUOC 4: KIEM TRA GHE CON TRONG
            // -------------------------------------------------

            List<Seat8> availableSeats =
                    loadAvailableSeats(showtimeId);

            List<Seat8> selectedSeats = new ArrayList<>();

            for (String seatId : selectedSeatIds) {

                Seat8 matchedSeat = null;

                for (Seat8 seat : availableSeats) {

                    if (seat.getSeatId().equals(seatId)) {

                        matchedSeat = seat;
                        break;
                    }
                }

                if (matchedSeat == null) {

                    throw new IllegalArgumentException(
                            "Mot trong cac ghe da duoc dat. "
                            + "Vui long chon lai."
                    );
                }

                selectedSeats.add(matchedSeat);
            }

            // -------------------------------------------------
            // BUOC 5: KIEM TRA MA THANH VIEN
            // -------------------------------------------------

            boolean membershipValid = false;

            if (membershipCode != null
                    && !membershipCode.trim().isEmpty()) {

                membershipValid = validateMembershipCode(
                        membershipCode,
                        session
                );

                // Co nhap ma nhung ma khong hop le:
                // Dung quy trinh mua ve, khong tao booking.
                if (!membershipValid) {

                    throw new IllegalArgumentException(
                            "Ma the thanh vien khong hop le, "
                            + "khong ton tai, da het han, chua co hieu luc "
                            + "hoac khong thuoc tai khoan cua ban."
                    );
                }
            }

            // -------------------------------------------------
            // BUOC 6: TINH TIEN
            // -------------------------------------------------

            // Tong tien truoc khi giam gia
            BigDecimal originalAmount = calculateTotalAmount(
                    selectedSeats,
                    selectedShowtime.getTicketPrice()
            );

            // Tinh tien duoc giam
            BigDecimal discount = BigDecimal.ZERO.setScale(2);

            if (membershipValid) {

                discount = originalAmount
                        .multiply(DISCOUNT_RATE)
                        .setScale(2, RoundingMode.HALF_UP);
            }

            // Tong tien sau khi giam gia
            BigDecimal finalAmount = originalAmount
                    .subtract(discount)
                    .setScale(2, RoundingMode.HALF_UP);

            // -------------------------------------------------
            // BUOC 7: TAO BOOKING
            // -------------------------------------------------

            Booking8 booking = new Booking8();

            String bookingId = generateId("BKG");

            booking.setBookingId(bookingId);
            booking.setCustomerId(getCustomerId(session));
            booking.setBookingTime(LocalDateTime.now());
            booking.setTotalAmount(finalAmount);
            booking.setBookingStatus("PENDING");
            booking.setPurchaseMethod("ONLINE");

            if (!createBooking(booking)) {

                throw new IllegalStateException(
                        "Khong the tao booking."
                );
            }

            // -------------------------------------------------
            // BUOC 8: THANH TOAN
            // -------------------------------------------------

            Payment8 payment = new Payment8();

            payment.setPaymentId(generateId("PAY"));
            payment.setBookingId(bookingId);
            payment.setAmount(finalAmount);
            payment.setPaymentMethod(paymentMethod);

            if (!makePayment(payment)) {

                throw new IllegalStateException(
                        "Thanh toan that bai."
                );
            }

            // -------------------------------------------------
            // BUOC 9: TAO VE CHO TUNG GHE
            // -------------------------------------------------

            List<Ticket8> createdTickets = new ArrayList<>();

            for (Seat8 seat : selectedSeats) {

                Ticket8 ticket = new Ticket8();

                ticket.setTicketId(generateId("TKT"));
                ticket.setBookingId(bookingId);
                ticket.setShowtimeId(showtimeId);
                ticket.setSeatId(seat.getSeatId());

                ticket.setTicketPrice(
                        selectedShowtime.getTicketPrice()
                );

                ticket.setTicketStatus("SOLD");

                if (!createTicket(ticket)) {

                    throw new IllegalStateException(
                            "Khong the tao ve cho ghe "
                            + seat.getSeatNumber()
                    );
                }

                createdTickets.add(ticket);
            }

            // -------------------------------------------------
            // BUOC 10: TAO HOA DON
            // -------------------------------------------------

            Invoice8 invoice = new Invoice8();

            invoice.setInvoiceId(generateId("INV"));
            invoice.setBookingId(bookingId);

            invoice.setIssueDate(
                    Date.valueOf(LocalDate.now())
            );

            // Hoa don luu tien goc
            invoice.setTotalAmount(originalAmount);

            // So tien duoc giam
            invoice.setDiscount(discount);

            // So tien phai thanh toan
            invoice.setFinalAmount(finalAmount);

            if (!createInvoice(invoice)) {

                throw new IllegalStateException(
                        "Khong the tao hoa don."
                );
            }

            // -------------------------------------------------
            // BUOC 11: XAC NHAN BOOKING
            // -------------------------------------------------

            if (!bookingDAO.confirmTicketPurchase(bookingId)) {

                throw new IllegalStateException(
                        "Khong the xac nhan booking."
                );
            }

            booking.setBookingStatus("COMPLETED");

            // -------------------------------------------------
            // BUOC 12: GUI DU LIEU SANG JSP
            // -------------------------------------------------

            request.setAttribute("booking", booking);
            request.setAttribute("payment", payment);
            request.setAttribute("invoice", invoice);

            request.setAttribute("selectedMovie", selectedMovie);
            request.setAttribute("selectedShowtime", selectedShowtime);
            request.setAttribute("selectedSeats", selectedSeats);

            request.setAttribute("ticketList", createdTickets);

            request.setAttribute("originalAmount", originalAmount);
            request.setAttribute("discount", discount);
            request.setAttribute("finalAmount", finalAmount);

            request.setAttribute("membershipValid", membershipValid);

            request.setAttribute("purchaseSuccess", true);

            request.setAttribute(
                    "successMessage",
                    "Mua ve thanh cong!"
            );

        } catch (Exception e) {

            e.printStackTrace();

            request.setAttribute(
                    "errorMessage",
                    e.getMessage() == null
                            ? "Da xay ra loi khi mua ve."
                            : e.getMessage()
            );
        }

        // -------------------------------------------------
        // BUOC 13: LOAD LAI DU LIEU VA HIEN THI JSP
        // -------------------------------------------------

        reloadFormData(request, movieId, showtimeId);

        forwardToView(request, response);
    }
}
