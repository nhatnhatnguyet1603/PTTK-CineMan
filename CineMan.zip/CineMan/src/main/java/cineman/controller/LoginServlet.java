
package cineman.controller;

import cineman.util.DBConnection;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String role = request.getParameter("role");
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Kiểm tra dữ liệu đầu vào
        if (username == null || password == null
                || username.trim().isEmpty()
                || password.isEmpty()
                || (!"manager".equals(role)
                && !"customer".equals(role))) {

            response.sendRedirect(
                    request.getContextPath() + "/index.jsp"
            );
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {

            if (conn == null) {
                throw new SQLException(
                        "Khong the ket noi database!"
                );
            }

            // =========================================
            // DANG NHAP MANAGER
            // =========================================

            if ("manager".equals(role)) {

                String sql = """
                    SELECT e.employeeId, e.fullName, e.username
                    FROM Employee8 e
                    INNER JOIN Manager8 m
                        ON e.employeeId = m.employeeId
                    WHERE e.username = ?
                      AND e.password = ?
                    """;

                try (PreparedStatement ps =
                             conn.prepareStatement(sql)) {

                    ps.setString(1, username.trim());
                    ps.setString(2, password);

                    try (ResultSet rs = ps.executeQuery()) {

                        if (rs.next()) {

                            // Huy session cu neu ton tai
                            HttpSession oldSession =
                                    request.getSession(false);

                            if (oldSession != null) {
                                oldSession.invalidate();
                            }

                            // Tao session moi
                            HttpSession session =
                                    request.getSession(true);

                            session.setAttribute(
                                    "userRole", "manager"
                            );

                            session.setAttribute(
                                    "employeeId",
                                    rs.getString("employeeId")
                            );

                            session.setAttribute(
                                    "fullName",
                                    rs.getString("fullName")
                            );

                            session.setAttribute(
                                    "username",
                                    rs.getString("username")
                            );

                            // Chuyen den Manager Main Menu
                            response.sendRedirect(
                                    request.getContextPath()
                                            + "/ManagerMainMenu8"
                            );

                            return;
                        }
                    }
                }

            }

            // =========================================
            // DANG NHAP CUSTOMER
            // =========================================

            else {

                String sql = """
                    SELECT customerId, fullName, username
                    FROM Customer8
                    WHERE username = ?
                      AND password = ?
                    """;

                try (PreparedStatement ps =
                             conn.prepareStatement(sql)) {

                    ps.setString(1, username.trim());
                    ps.setString(2, password);

                    try (ResultSet rs = ps.executeQuery()) {

                        if (rs.next()) {

                            // Huy session cu neu ton tai
                            HttpSession oldSession =
                                    request.getSession(false);

                            if (oldSession != null) {
                                oldSession.invalidate();
                            }

                            // Tao session moi
                            HttpSession session =
                                    request.getSession(true);

                            session.setAttribute(
                                    "userRole", "customer"
                            );

                            session.setAttribute(
                                    "customerId",
                                    rs.getString("customerId")
                            );

                            session.setAttribute(
                                    "fullName",
                                    rs.getString("fullName")
                            );

                            session.setAttribute(
                                    "username",
                                    rs.getString("username")
                            );

                            // Chuyen den Customer Main Menu
                            response.sendRedirect(
                                    request.getContextPath()
                                            + "/CustomerMainMenu8"
                            );

                            return;
                        }
                    }
                }
            }

            // =========================================
            // SAI TAI KHOAN HOAC MAT KHAU
            // =========================================

            response.sendRedirect(
                    request.getContextPath()
                            + "/login.jsp?role=" + role + "&error=1"
            );

        } catch (SQLException e) {

            e.printStackTrace();

            response.sendError(
                    HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    "Loi truy cap co so du lieu!"
            );
        }
    }
}
