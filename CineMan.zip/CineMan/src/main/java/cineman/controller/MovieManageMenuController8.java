package cineman.controller;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/MovieManageMenu8")
public class MovieManageMenuController8 extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null
                || (session.getAttribute("employeeId") == null
                && session.getAttribute("managerId") == null)) {

            response.sendRedirect(
                    request.getContextPath() + "/login.jsp"
            );

            return;
        }

        request.getRequestDispatcher(
                "/WEB-INF/views/admin/movie-manage-menu.jsp"
        ).forward(request, response);
    }
}