
package cineman.dao;

import cineman.model.Ticket8;
import cineman.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class TicketDAO8 {

    // Tao va luu mot ve
    public boolean createTicket(Ticket8 ticket) {

        String sql = """
            INSERT INTO Ticket8
            (ticketId, bookingId, showtimeId,
             seatId, ticketPrice, ticketStatus)
            VALUES (?, ?, ?, ?, ?, ?)
        """;

        try (Connection conn = DBConnection.getConnection()) {

            if (conn == null) {
                throw new SQLException("Khong ket noi duoc database.");
            }

            if (ticket.getTicketId() == null
                    || ticket.getTicketId().isBlank()) {
                ticket.setTicketId(
                    "TKT" + UUID.randomUUID()
                    .toString().replace("-", "")
                    .substring(0, 17).toUpperCase()
                );
            }

            try (PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setString(1, ticket.getTicketId());
                ps.setString(2, ticket.getBookingId());
                ps.setString(3, ticket.getShowtimeId());
                ps.setString(4, ticket.getSeatId());
                ps.setBigDecimal(5, ticket.getTicketPrice());
                ps.setString(6, "SOLD");

                return ps.executeUpdate() > 0;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Lay danh sach ve theo ma booking
    public List<Ticket8> getTicketsByBookingId(String bookingId) {

        List<Ticket8> ticketList = new ArrayList<>();

        String sql = """
            SELECT *
            FROM Ticket8
            WHERE bookingId = ?
            ORDER BY ticketId
        """;

        try (Connection conn = DBConnection.getConnection()) {

            if (conn == null) {
                throw new SQLException("Khong ket noi duoc database.");
            }

            try (PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setString(1, bookingId);

                try (ResultSet rs = ps.executeQuery()) {

                    while (rs.next()) {

                        Ticket8 ticket = new Ticket8();

                        ticket.setTicketId(rs.getString("ticketId"));
                        ticket.setBookingId(rs.getString("bookingId"));
                        ticket.setShowtimeId(rs.getString("showtimeId"));
                        ticket.setSeatId(rs.getString("seatId"));
                        ticket.setTicketPrice(rs.getBigDecimal("ticketPrice"));
                        ticket.setTicketStatus(rs.getString("ticketStatus"));

                        ticketList.add(ticket);
                    }
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return ticketList;
    }
}
