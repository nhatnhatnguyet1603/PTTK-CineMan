
package cineman.dao;

import cineman.model.Seat8;
import cineman.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SeatDAO8 {

    // Lay danh sach ghe chua duoc ban trong suat chieu
    public List<Seat8> getAvailableSeats(String showtimeId) {

        List<Seat8> seatList = new ArrayList<>();

        String sql = """
            SELECT s.seatId, s.roomId, s.seatNumber,
                   s.`row`, s.seatType, s.status
            FROM Seat8 s
            INNER JOIN Showtime8 st
                ON s.roomId = st.roomId
            WHERE st.showtimeId = ?
              AND UPPER(s.status) = 'AVAILABLE'
              AND NOT EXISTS (
                  SELECT 1
                  FROM Ticket8 t
                  INNER JOIN Booking8 b
                      ON t.bookingId = b.bookingId
                  WHERE t.showtimeId = st.showtimeId
                    AND t.seatId = s.seatId
                    AND UPPER(t.ticketStatus) = 'SOLD'
                    AND UPPER(b.bookingStatus) = 'COMPLETED'
              )
            ORDER BY   LEFT(seatNumber, 1) ASC,
    CAST(SUBSTRING(seatNumber, 2) AS UNSIGNED) ASC
        """;

        try (Connection conn = DBConnection.getConnection()) {

            if (conn == null) {
                throw new SQLException("Khong ket noi duoc database.");
            }

            try (PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setString(1, showtimeId);

                try (ResultSet rs = ps.executeQuery()) {

                    while (rs.next()) {

                        Seat8 seat = new Seat8();

                        seat.setSeatId(rs.getString("seatId"));
                        seat.setRoomId(rs.getString("roomId"));
                        seat.setSeatNumber(rs.getString("seatNumber"));
                        seat.setRow(rs.getString("row"));
                        seat.setSeatType(rs.getString("seatType"));
                        seat.setStatus(rs.getString("status"));

                        seatList.add(seat);
                    }
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return seatList;
    }
}
