
package cineman.dao;

import cineman.model.Booking8;
import cineman.util.DBConnection;

import java.sql.*;
import java.util.UUID;

public class BookingDAO8 {

    // Tao ma booking
    private String generateBookingId() {
        return "BKG" + UUID.randomUUID()
                .toString().replace("-", "")
                .substring(0, 17).toUpperCase();
    }

    // Luu thong tin booking
    public boolean createBooking(Booking8 booking) {

        String sql = """
            INSERT INTO Booking8
            (bookingId, customerId, bookingTime,
             totalAmount, bookingStatus, purchaseMethod)
            VALUES (?, ?, ?, ?, ?, ?)
        """;

        try (Connection conn = DBConnection.getConnection()) {

            if (conn == null) {
                throw new SQLException("Khong ket noi duoc database.");
            }

            if (booking.getBookingId() == null
                    || booking.getBookingId().isBlank()) {
                booking.setBookingId(generateBookingId());
            }

            try (PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setString(1, booking.getBookingId());
                ps.setString(2, booking.getCustomerId());
                ps.setTimestamp(3,
                        Timestamp.valueOf(booking.getBookingTime()));
                ps.setBigDecimal(4, booking.getTotalAmount());
                ps.setString(5, "PENDING");
                ps.setString(6, "ONLINE");

                return ps.executeUpdate() > 0;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Xac nhan booking sau khi hoan tat thanh toan
    public boolean confirmTicketPurchase(String bookingId) {

        String sql = """
            UPDATE Booking8
            SET bookingStatus = 'COMPLETED'
            WHERE bookingId = ?
              AND UPPER(bookingStatus) = 'PENDING'
        """;

        try (Connection conn = DBConnection.getConnection()) {

            if (conn == null) {
                throw new SQLException("Khong ket noi duoc database.");
            }

            try (PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setString(1, bookingId);

                return ps.executeUpdate() == 1;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
