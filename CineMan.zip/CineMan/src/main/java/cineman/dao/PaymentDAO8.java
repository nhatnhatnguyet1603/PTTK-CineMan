
package cineman.dao;

import cineman.model.Payment8;
import cineman.util.DBConnection;

import java.sql.*;
import java.util.UUID;

public class PaymentDAO8 {

    // Luu thong tin thanh toan
    public boolean savePayment(Payment8 payment) {

        String sql = """
            INSERT INTO Payment8
            (paymentId, bookingId, paymentTime,
             amount, paymentMethod, paymentStatus)
            VALUES (?, ?, ?, ?, ?, ?)
        """;

        try (Connection conn = DBConnection.getConnection()) {

            if (conn == null) {
                throw new SQLException("Khong ket noi duoc database.");
            }

            if (payment.getPaymentId() == null
                    || payment.getPaymentId().isBlank()) {
                payment.setPaymentId(
                        "PAY" + UUID.randomUUID()
                        .toString().replace("-", "")
                        .substring(0, 17).toUpperCase());
            }

            try (PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setString(1, payment.getPaymentId());
                ps.setString(2, payment.getBookingId());
                ps.setTimestamp(3,
                        Timestamp.valueOf(payment.getPaymentTime()));
                ps.setBigDecimal(4, payment.getAmount());
                ps.setString(5, payment.getPaymentMethod());
                ps.setString(6, payment.getPaymentStatus());

                return ps.executeUpdate() > 0;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Lay thong tin thanh toan theo booking
    public Payment8 getPaymentByBookingId(String bookingId) {

        String sql = """
            SELECT *
            FROM Payment8
            WHERE bookingId = ?
            ORDER BY paymentTime DESC
            LIMIT 1
        """;

        try (Connection conn = DBConnection.getConnection()) {

            if (conn == null) {
                throw new SQLException("Khong ket noi duoc database.");
            }

            try (PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setString(1, bookingId);

                try (ResultSet rs = ps.executeQuery()) {

                    if (rs.next()) {

                        Payment8 payment = new Payment8();

                        payment.setPaymentId(rs.getString("paymentId"));
                        payment.setBookingId(rs.getString("bookingId"));

                        Timestamp time = rs.getTimestamp("paymentTime");

                        if (time != null) {
                            payment.setPaymentTime(
                                    time.toLocalDateTime());
                        }

                        payment.setAmount(rs.getBigDecimal("amount"));
                        payment.setPaymentMethod(
                                rs.getString("paymentMethod"));
                        payment.setPaymentStatus(
                                rs.getString("paymentStatus"));

                        return payment;
                    }
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }
}
