
package cineman.dao;

import cineman.model.MembershipCard8;
import cineman.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MembershipCardDAO8 {

    public MembershipCard8 validateMembershipCode(
            String membershipCode,
            String customerId) {

        if (membershipCode == null || membershipCode.trim().isEmpty()
                || customerId == null || customerId.trim().isEmpty()) {
            return null;
        }

        String sql = """
            SELECT membershipCardId,
                   customerId,
                   membershipCode,
                   issueDate,
                   expiryDate,
                   status
            FROM MembershipCard8
            WHERE UPPER(TRIM(membershipCode)) = UPPER(TRIM(?))
              AND TRIM(customerId) = TRIM(?)
              AND UPPER(TRIM(status)) = 'ACTIVE'
              AND issueDate <= CURDATE()
              AND expiryDate >= CURDATE()
            LIMIT 1
        """;

        try (Connection conn = DBConnection.getConnection()) {

            if (conn == null) {
                throw new SQLException("Khong ket noi duoc database.");
            }

            try (PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setString(1, membershipCode.trim());
                ps.setString(2, customerId.trim());

                try (ResultSet rs = ps.executeQuery()) {

                    if (rs.next()) {

                        MembershipCard8 card = new MembershipCard8();

                        card.setMembershipCardId(
                                rs.getString("membershipCardId"));

                        card.setCustomerId(
                                rs.getString("customerId"));

                        card.setMembershipCode(
                                rs.getString("membershipCode"));

                        card.setIssueDate(
                                rs.getDate("issueDate"));

                        card.setExpiryDate(
                                rs.getDate("expiryDate"));

                        card.setStatus(
                                rs.getString("status"));

                        return card;
                    }
                }
            }

        } catch (SQLException e) {

            e.printStackTrace();

            throw new RuntimeException(
                    "Loi kiem tra Membership Card: " + e.getMessage(), e
            );
        }

        return null;
    }
}
