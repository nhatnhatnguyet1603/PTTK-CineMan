
package cineman.dao;

import cineman.model.Showtime8;
import cineman.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ShowtimeDAO8 {

    // Lay danh sach suat chieu con hieu luc cua mot bo phim
    public List<Showtime8> getShowtimeList(String movieId) {

        List<Showtime8> showtimeList = new ArrayList<>();

        String sql = """
            SELECT showtimeId, movieId, roomId,
                   startTime, endTime, ticketPrice, status
            FROM Showtime8
            WHERE movieId = ?
              AND UPPER(status) = 'ACTIVE'
              AND startTime > NOW()
            ORDER BY startTime ASC
        """;

        try (Connection conn = DBConnection.getConnection()) {

            if (conn == null) {
                throw new SQLException("Khong ket noi duoc database.");
            }

            try (PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setString(1, movieId);

                try (ResultSet rs = ps.executeQuery()) {

                    while (rs.next()) {

                        Showtime8 showtime = new Showtime8();

                        showtime.setShowtimeId(rs.getString("showtimeId"));
                        showtime.setMovieId(rs.getString("movieId"));
                        showtime.setRoomId(rs.getString("roomId"));

                        Timestamp start = rs.getTimestamp("startTime");
                        Timestamp end = rs.getTimestamp("endTime");

                        if (start != null) {
                            showtime.setStartTime(start.toLocalDateTime());
                        }

                        if (end != null) {
                            showtime.setEndTime(end.toLocalDateTime());
                        }

                        showtime.setTicketPrice(
                                rs.getBigDecimal("ticketPrice"));

                        showtime.setStatus(rs.getString("status"));

                        showtimeList.add(showtime);
                    }
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return showtimeList;
    }
}
