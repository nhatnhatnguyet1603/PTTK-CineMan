
package cineman.dao;

import cineman.model.Invoice8;
import cineman.util.DBConnection;

import java.sql.*;
import java.util.UUID;

public class InvoiceDAO8 {

    // Tao va luu hoa don
    public boolean createInvoice(Invoice8 invoice) {

        String sql = """
            INSERT INTO Invoice8
            (invoiceId, bookingId, issueDate,
             totalAmount, discount, finalAmount)
            VALUES (?, ?, ?, ?, ?, ?)
        """;

        try (Connection conn = DBConnection.getConnection()) {

            if (conn == null) {
                throw new SQLException("Khong ket noi duoc database.");
            }

            if (invoice.getInvoiceId() == null
                    || invoice.getInvoiceId().isBlank()) {
                invoice.setInvoiceId(
                    "INV" + UUID.randomUUID()
                    .toString().replace("-", "")
                    .substring(0, 17).toUpperCase()
                );
            }

            try (PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setString(1, invoice.getInvoiceId());
                ps.setString(2, invoice.getBookingId());
                ps.setDate(3, invoice.getIssueDate());
                ps.setBigDecimal(4, invoice.getTotalAmount());
                ps.setBigDecimal(5, invoice.getDiscount());
                ps.setBigDecimal(6, invoice.getFinalAmount());

                return ps.executeUpdate() > 0;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Lay hoa don theo ma booking
    public Invoice8 getInvoiceByBookingId(String bookingId) {

        String sql = """
            SELECT *
            FROM Invoice8
            WHERE bookingId = ?
            ORDER BY issueDate DESC
            LIMIT 1
        """;

        try (Connection conn = DBConnection.getConnection()) {

            if (conn == null) {
                throw new SQLException("Khong ket noi duoc database.");
            }

            try (PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setString(1, bookingId);

                try (ResultSet rs = ps.executeQuery()) {

                    if (rs.next()) {

                        Invoice8 invoice = new Invoice8();

                        invoice.setInvoiceId(rs.getString("invoiceId"));
                        invoice.setBookingId(rs.getString("bookingId"));
                        invoice.setIssueDate(rs.getDate("issueDate"));
                        invoice.setTotalAmount(rs.getBigDecimal("totalAmount"));
                        invoice.setDiscount(rs.getBigDecimal("discount"));
                        invoice.setFinalAmount(rs.getBigDecimal("finalAmount"));

                        return invoice;
                    }
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }
}
