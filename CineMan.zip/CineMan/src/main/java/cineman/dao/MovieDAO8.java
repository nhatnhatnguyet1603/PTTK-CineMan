
package cineman.dao;

import cineman.model.Movie8;
import cineman.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import java.math.BigDecimal;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class MovieDAO8 {

    // =====================================================
    // CAU HINH LICH CHIEU
    // =====================================================

    private static final LocalTime[] SHOWTIMES = {
        LocalTime.of(9, 0),
        LocalTime.of(12, 0),
        LocalTime.of(15, 0),
        LocalTime.of(18, 0),
        LocalTime.of(21, 0)
    };

    private static final int MAX_SHOWTIMES_PER_DAY = 2;

    private static final BigDecimal PRICE_2D_NORMAL =
            new BigDecimal("70000");

    private static final BigDecimal PRICE_2D_GOLDEN =
            new BigDecimal("90000");

    private static final BigDecimal PRICE_3D_NORMAL =
            new BigDecimal("90000");

    private static final BigDecimal PRICE_3D_GOLDEN =
            new BigDecimal("110000");


    // =====================================================
    // THONG TIN PHONG CHIEU
    // =====================================================

    private static class RoomInfo {

        private final String roomId;
        private final String roomType;

        public RoomInfo(String roomId, String roomType) {
            this.roomId = roomId;
            this.roomType = roomType;
        }
    }


    // =====================================================
    // SINH MA PHIM VA MA SUAT CHIEU
    // =====================================================

    private String generateMovieId() {

        return "MOV"
                + UUID.randomUUID()
                        .toString()
                        .replace("-", "")
                        .substring(0, 17)
                        .toUpperCase();
    }

    private String generateShowtimeId() {

        return "SHOW"
                + UUID.randomUUID()
                        .toString()
                        .replace("-", "")
                        .substring(0, 16)
                        .toUpperCase();
    }


    // =====================================================
    // TINH GIA VE
    // =====================================================

    private BigDecimal calculateTicketPrice(
            String roomType,
            LocalTime showTime) {

        boolean goldenHour =
                LocalTime.of(18, 0).equals(showTime);

        if ("2D".equalsIgnoreCase(roomType)) {
            return goldenHour
                    ? PRICE_2D_GOLDEN
                    : PRICE_2D_NORMAL;
        }

        if ("3D".equalsIgnoreCase(roomType)) {
            return goldenHour
                    ? PRICE_3D_GOLDEN
                    : PRICE_3D_NORMAL;
        }

        return null;
    }


    // =====================================================
    // LAY CAC PHONG DANG HOAT DONG
    // KHOA CAC BAN GHI PHONG TRONG TRANSACTION
    // =====================================================

    private List<RoomInfo> getActiveRooms(
            Connection conn) throws SQLException {

        List<RoomInfo> rooms = new ArrayList<>();

        String sql = """
            SELECT roomId, roomType
            FROM CinemaRoom8
            WHERE UPPER(status) = 'ACTIVE'
            ORDER BY roomId ASC
            FOR UPDATE
            """;

        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                String roomId = rs.getString("roomId");
                String roomType = rs.getString("roomType");

                // Chi nhan phong 2D va 3D
                if (calculateTicketPrice(
                        roomType,
                        LocalTime.of(9, 0)) != null) {

                    rooms.add(new RoomInfo(roomId, roomType));
                }
            }
        }

        return rooms;
    }


    // =====================================================
    // KIEM TRA PHONG CO BI TRUNG LICH KHONG
    // KHONG TINH CAC SUAT DA HUY
    // =====================================================

    private boolean isRoomOccupied(
            Connection conn,
            String roomId,
            LocalDateTime startTime,
            LocalDateTime endTime) throws SQLException {

        String sql = """
            SELECT COUNT(*)
            FROM Showtime8
            WHERE roomId = ?
              AND UPPER(COALESCE(status, '')) <> 'CANCELLED'
              AND startTime < ?
              AND endTime > ?
            """;

        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, roomId);
            ps.setTimestamp(2, Timestamp.valueOf(endTime));
            ps.setTimestamp(3, Timestamp.valueOf(startTime));

            try (ResultSet rs = ps.executeQuery()) {

                return rs.next() && rs.getInt(1) > 0;
            }
        }
    }


    // =====================================================
    // KIEM TRA PHIM DA CO SUAT CHIEU O KHUNG GIO NAY CHUA
    // TRANH TAO HAI SUAT CUNG GIO CHO MOT PHIM
    // =====================================================

    private boolean isMovieScheduledAt(
            Connection conn,
            String movieId,
            LocalDateTime startTime) throws SQLException {

        String sql = """
            SELECT COUNT(*)
            FROM Showtime8
            WHERE movieId = ?
              AND startTime = ?
              AND UPPER(COALESCE(status, '')) <> 'CANCELLED'
            """;

        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, movieId);
            ps.setTimestamp(2, Timestamp.valueOf(startTime));

            try (ResultSet rs = ps.executeQuery()) {

                return rs.next() && rs.getInt(1) > 0;
            }
        }
    }


    // =====================================================
    // DEM SO SUAT CHIEU CUA PHIM TRONG MOT NGAY
    // =====================================================

    private int countMovieShowtimes(
            Connection conn,
            String movieId,
            LocalDate date) throws SQLException {

        String sql = """
            SELECT COUNT(*)
            FROM Showtime8
            WHERE movieId = ?
              AND startTime >= ?
              AND startTime < ?
              AND UPPER(COALESCE(status, '')) <> 'CANCELLED'
            """;

        LocalDateTime dayStart = date.atStartOfDay();
        LocalDateTime nextDay = date.plusDays(1).atStartOfDay();

        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, movieId);
            ps.setTimestamp(2, Timestamp.valueOf(dayStart));
            ps.setTimestamp(3, Timestamp.valueOf(nextDay));

            try (ResultSet rs = ps.executeQuery()) {

                return rs.next() ? rs.getInt(1) : 0;
            }
        }
    }


    // =====================================================
    // TAO MOT SUAT CHIEU
    // =====================================================

    private boolean insertShowtime(
            Connection conn,
            Movie8 movie,
            RoomInfo room,
            LocalDateTime startTime) throws SQLException {

        LocalDateTime endTime =
                startTime.plusMinutes(movie.getDuration());

        String sql = """
            INSERT INTO Showtime8
            (showtimeId, movieId, roomId,
             startTime, endTime, ticketPrice, status)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """;

        BigDecimal ticketPrice = calculateTicketPrice(
                room.roomType,
                startTime.toLocalTime()
        );

        if (ticketPrice == null) {
            return false;
        }

        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, generateShowtimeId());
            ps.setString(2, movie.getMovieId());
            ps.setString(3, room.roomId);

            ps.setTimestamp(
                    4,
                    Timestamp.valueOf(startTime)
            );

            ps.setTimestamp(
                    5,
                    Timestamp.valueOf(endTime)
            );

            ps.setBigDecimal(6, ticketPrice);
            ps.setString(7, "ACTIVE");

            return ps.executeUpdate() > 0;
        }
    }


    // =====================================================
    // THU TAO MOT SUAT CHIEU CHO PHIM
    // TIM KHUNG GIO VA PHONG CON TRONG
    // =====================================================

    private boolean tryScheduleOneShowtime(
            Connection conn,
            Movie8 movie,
            List<RoomInfo> rooms,
            LocalDate date) throws SQLException {

        LocalDateTime now = LocalDateTime.now();

        // Xoay vong thu tu khung gio theo tung phim va tung ngay
        int slotOffset = Math.floorMod(
                movie.getMovieId().hashCode() + date.getDayOfYear(),
                SHOWTIMES.length
        );

        for (int i = 0; i < SHOWTIMES.length; i++) {

            int slotIndex = (slotOffset + i) % SHOWTIMES.length;

            LocalTime slot = SHOWTIMES[slotIndex];

            LocalDateTime showStart =
                    LocalDateTime.of(date, slot);

            LocalDateTime showEnd =
                    showStart.plusMinutes(movie.getDuration());

            // Khong tao suat chieu da qua
            if (!showStart.isAfter(now)) {
                continue;
            }

            // Khong xep hai suat cung gio cho mot phim
            if (isMovieScheduledAt(
                    conn,
                    movie.getMovieId(),
                    showStart)) {

                continue;
            }

            // Xoay vong phong chieu
            int roomOffset = (slotIndex + date.getDayOfYear())
                    % rooms.size();

            for (int j = 0; j < rooms.size(); j++) {

                RoomInfo room = rooms.get(
                        (roomOffset + j) % rooms.size()
                );

                // Kiem tra phong co lich chieu trung khong
                if (isRoomOccupied(
                        conn,
                        room.roomId,
                        showStart,
                        showEnd)) {

                    continue;
                }

                // Tao suat chieu
                return insertShowtime(
                        conn,
                        movie,
                        room,
                        showStart
                );
            }
        }

        // Khong tim duoc phong va khung gio phu hop
        return false;
    }


    // =====================================================
    // CAP NHAT TRANG THAI PHIM
    // =====================================================

    private void updateMovieStatuses(
            Connection conn) throws SQLException {

        String sql = """
            UPDATE Movie8
            SET status = CASE
                WHEN CURDATE() < startDate THEN 'UPCOMING'
                WHEN CURDATE() > endDate THEN 'INACTIVE'
                ELSE 'ACTIVE'
            END
            WHERE startDate IS NOT NULL
              AND endDate IS NOT NULL
            """;

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.executeUpdate();
        }
    }


    // =====================================================
    // LAY DANH SACH PHIM CAN DUOC XEP LICH
    // BAO GOM PHIM UPCOMING VA ACTIVE
    // =====================================================

    private List<Movie8> getMoviesForScheduling(
            Connection conn) throws SQLException {

        List<Movie8> movies = new ArrayList<>();

        String sql = """
            SELECT movieId, managerId, movieName, genre,
                   duration, description, startDate, endDate, status
            FROM Movie8
            WHERE status IN ('UPCOMING', 'ACTIVE')
              AND startDate IS NOT NULL
              AND endDate IS NOT NULL
              AND duration > 0
            ORDER BY startDate ASC, movieId ASC
            FOR UPDATE
            """;

        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                Movie8 movie = new Movie8();

                movie.setMovieId(rs.getString("movieId"));
                movie.setManagerId(rs.getString("managerId"));
                movie.setMovieName(rs.getString("movieName"));
                movie.setGenre(rs.getString("genre"));
                movie.setDuration(rs.getInt("duration"));
                movie.setDescription(rs.getString("description"));
                movie.setStartDate(rs.getDate("startDate"));
                movie.setEndDate(rs.getDate("endDate"));
                movie.setStatus(rs.getString("status"));

                movies.add(movie);
            }
        }

        return movies;
    }


    // =====================================================
    // BO LAP LICH TU DONG
    // MOI PHIM TOI DA 2 SUAT / NGAY
    // UU TIEN MOI PHIM CO 1 SUAT TRUOC
    // SAU DO MOI BO SUNG SUAT THU 2
    // =====================================================

    private int schedulePendingMovies(
            Connection conn) throws SQLException {

        // Cap nhat trang thai phim truoc khi xep lich
        updateMovieStatuses(conn);

        // Lay cac phong dang hoat dong
        List<RoomInfo> rooms = getActiveRooms(conn);

        if (rooms.isEmpty()) {
            return 0;
        }

        // Lay cac phim con trong thoi gian chieu
        List<Movie8> movies = getMoviesForScheduling(conn);

        if (movies.isEmpty()) {
            return 0;
        }

        LocalDate today = LocalDate.now();

        LocalDate lastDate = null;

        for (Movie8 movie : movies) {

            LocalDate endDate = movie.getEndDate().toLocalDate();

            if (lastDate == null || endDate.isAfter(lastDate)) {
                lastDate = endDate;
            }
        }

        if (lastDate == null || lastDate.isBefore(today)) {
            return 0;
        }

        int totalCreated = 0;

        // Duyet tung ngay
        for (LocalDate date = today;
             !date.isAfter(lastDate);
             date = date.plusDays(1)) {

            List<Movie8> eligibleMovies = new ArrayList<>();

            for (Movie8 movie : movies) {

                LocalDate startDate =
                        movie.getStartDate().toLocalDate();

                LocalDate endDate =
                        movie.getEndDate().toLocalDate();

                if (!date.isBefore(startDate)
                        && !date.isAfter(endDate)) {

                    eligibleMovies.add(movie);
                }
            }

            // -------------------------------------------------
            // VONG 1: MOI PHIM CO TOI DA 1 SUAT TRONG NGAY
            // -------------------------------------------------

            for (Movie8 movie : eligibleMovies) {

                int currentCount = countMovieShowtimes(
                        conn,
                        movie.getMovieId(),
                        date
                );

                if (currentCount >= 1) {
                    continue;
                }

                if (tryScheduleOneShowtime(
                        conn,
                        movie,
                        rooms,
                        date)) {

                    totalCreated++;
                }
            }

            // -------------------------------------------------
            // VONG 2: BO SUNG SUAT THU 2 CHO CAC PHIM
            // CHI THUC HIEN SAU KHI DA XET VONG 1
            // -------------------------------------------------

            for (Movie8 movie : eligibleMovies) {

                int currentCount = countMovieShowtimes(
                        conn,
                        movie.getMovieId(),
                        date
                );

                if (currentCount >= MAX_SHOWTIMES_PER_DAY) {
                    continue;
                }

                if (tryScheduleOneShowtime(
                        conn,
                        movie,
                        rooms,
                        date)) {

                    totalCreated++;
                }
            }
        }

        return totalCreated;
    }


    // =====================================================
    // THEM PHIM VA TU DONG XEP LICH
    // =====================================================

    public boolean addMovie(Movie8 movie) {

        if (movie == null
                || movie.getStartDate() == null
                || movie.getEndDate() == null
                || movie.getDuration() <= 0
                || movie.getStartDate().after(movie.getEndDate())) {

            return false;
        }

        String sql = """
            INSERT INTO Movie8
            (movieId, managerId, movieName, genre, duration,
             description, startDate, endDate, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """;

        Connection conn = null;

        try {

            conn = DBConnection.getConnection();

            if (conn == null) {
                return false;
            }

            // Bat dau transaction
            conn.setAutoCommit(false);

            String movieId = generateMovieId();

            movie.setMovieId(movieId);

            // Buoc 1: Them phim moi
            try (PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setString(1, movieId);
                ps.setString(2, movie.getManagerId());
                ps.setString(3, movie.getMovieName());
                ps.setString(4, movie.getGenre());
                ps.setInt(5, movie.getDuration());
                ps.setString(6, movie.getDescription());
                ps.setDate(7, movie.getStartDate());
                ps.setDate(8, movie.getEndDate());
                ps.setString(9, movie.getStatus());

                if (ps.executeUpdate() <= 0) {
                    throw new SQLException(
                            "Khong them duoc phim."
                    );
                }
            }

            // Buoc 2: Thu xep lich cho tat ca phim
            // Bao gom phim moi va phim chua du suat truoc do
            int createdCount = schedulePendingMovies(conn);

            // Buoc 3: Luu tat ca thay doi
            conn.commit();

            System.out.println(
                    "Them phim thanh cong: " + movieId
            );

            System.out.println(
                    "So suat chieu moi duoc tao: " + createdCount
            );

            return true;

        } catch (Exception e) {

            // Neu loi SQL thi rollback transaction
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException rollbackError) {
                    rollbackError.printStackTrace();
                }
            }

            e.printStackTrace();

            movie.setMovieId(null);

            return false;

        } finally {

            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }


    // =====================================================
    // LAY DANH SACH PHIM ACTIVE CHO DAT VE
    // =====================================================

    public List<Movie8> getMovieList() {

        List<Movie8> movieList = new ArrayList<>();

        String updateStatusSQL = """
            UPDATE Movie8
            SET status = CASE
                WHEN CURDATE() < startDate THEN 'UPCOMING'
                WHEN CURDATE() > endDate THEN 'INACTIVE'
                ELSE 'ACTIVE'
            END
            WHERE startDate IS NOT NULL
              AND endDate IS NOT NULL
            """;

        String selectSQL = """
            SELECT movieId, managerId, movieName, genre,
                   duration, description, startDate, endDate, status
            FROM Movie8
            WHERE status = 'ACTIVE'
            ORDER BY startDate ASC
            """;

        try (Connection conn = DBConnection.getConnection()) {

            if (conn == null) {
                return movieList;
            }

            try (PreparedStatement ps =
                         conn.prepareStatement(updateStatusSQL)) {
                ps.executeUpdate();
            }

            try (PreparedStatement ps =
                         conn.prepareStatement(selectSQL);
                 ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {

                    Movie8 movie = new Movie8();

                    movie.setMovieId(rs.getString("movieId"));
                    movie.setManagerId(rs.getString("managerId"));
                    movie.setMovieName(rs.getString("movieName"));
                    movie.setGenre(rs.getString("genre"));
                    movie.setDuration(rs.getInt("duration"));
                    movie.setDescription(rs.getString("description"));
                    movie.setStartDate(rs.getDate("startDate"));
                    movie.setEndDate(rs.getDate("endDate"));
                    movie.setStatus(rs.getString("status"));

                    movieList.add(movie);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return movieList;
    }


    // =====================================================
    // KIEM TRA TEN PHIM DA TON TAI
    // =====================================================

    public boolean isMovieExists(String movieName)
            throws SQLException {

        String sql = """
            SELECT COUNT(*)
            FROM Movie8
            WHERE LOWER(TRIM(movieName)) = LOWER(TRIM(?))
            """;

        try (Connection conn = DBConnection.getConnection()) {

            if (conn == null) {
                throw new SQLException(
                        "Khong the ket noi co so du lieu."
                );
            }

            try (PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setString(1, movieName);

                try (ResultSet rs = ps.executeQuery()) {

                    return rs.next() && rs.getInt(1) > 0;
                }
            }
        }
    }


    // =====================================================
    // LAY TOAN BO DANH SACH PHIM CHO QUAN LY
    // =====================================================

    public List<Movie8> getAllMovieList() {

        List<Movie8> movieList = new ArrayList<>();

        String updateStatusSQL = """
            UPDATE Movie8
            SET status = CASE
                WHEN CURDATE() < startDate THEN 'UPCOMING'
                WHEN CURDATE() > endDate THEN 'INACTIVE'
                ELSE 'ACTIVE'
            END
            WHERE startDate IS NOT NULL
              AND endDate IS NOT NULL
            """;

        String selectSQL = """
            SELECT movieId, managerId, movieName, genre,
                   duration, description, startDate, endDate, status
            FROM Movie8
            ORDER BY startDate DESC
            """;

        try (Connection conn = DBConnection.getConnection()) {

            if (conn == null) {
                return movieList;
            }

            try (PreparedStatement ps =
                         conn.prepareStatement(updateStatusSQL)) {
                ps.executeUpdate();
            }

            try (PreparedStatement ps =
                         conn.prepareStatement(selectSQL);
                 ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {

                    Movie8 movie = new Movie8();

                    movie.setMovieId(rs.getString("movieId"));
                    movie.setManagerId(rs.getString("managerId"));
                    movie.setMovieName(rs.getString("movieName"));
                    movie.setGenre(rs.getString("genre"));
                    movie.setDuration(rs.getInt("duration"));
                    movie.setDescription(rs.getString("description"));
                    movie.setStartDate(rs.getDate("startDate"));
                    movie.setEndDate(rs.getDate("endDate"));
                    movie.setStatus(rs.getString("status"));

                    movieList.add(movie);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return movieList;
    }
}
