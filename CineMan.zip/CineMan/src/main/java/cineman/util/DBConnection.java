package cineman.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

    // Thong tin ket noi MySQL
    private static final String URL =
            "jdbc:mysql://localhost:3306/CineMan?useSSL=false&serverTimezone=Asia/Ho_Chi_Minh&allowPublicKeyRetrieval=true";

    private static final String USER = "root";

    private static final String PASSWORD = "nminh1603";

    // Ham tao ket noi den database
    public static Connection getConnection() {

        try {
            // Nap MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Tao ket noi
            Connection connection = DriverManager.getConnection(
                    URL, USER, PASSWORD
            );

            System.out.println("Ket noi database CineMan thanh cong!");

            return connection;

        } catch (ClassNotFoundException | SQLException e) {

            System.out.println("Loi ket noi database CineMan!");
            e.printStackTrace();

            return null;
        }
    }

    // Dong ket noi
    public static void closeConnection(Connection connection) {

        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
