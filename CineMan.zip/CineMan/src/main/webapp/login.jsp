<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%
String role = request.getParameter("role");
if (!"manager".equals(role) && !"customer".equals(role)) { response.sendRedirect(request.getContextPath()+"/index.jsp"); return; }
String title = "manager".equals(role) ? "Manager" : "Customer";
%>
<!DOCTYPE html><html lang="vi"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Đăng nhập <%=title%> - CineMan</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
<style>body{background:#f4f6fb}.login-card{max-width:440px;border:0;border-radius:20px;box-shadow:0 12px 35px #17203314}.btn-main{background:#315ce8;color:white}.btn-main:hover{background:#2449c5;color:white}</style>
</head><body>
<div class="container min-vh-100 d-flex align-items-center justify-content-center py-4">
<div class="card login-card w-100"><div class="card-body p-4 p-md-5">
<a href="<%=request.getContextPath()%>/index.jsp" class="text-decoration-none small">← Trang chủ</a>
<div class="text-center mt-3 mb-4"><div class="fs-1">🎬</div><h3 class="fw-bold">CineMan</h3><p class="text-secondary mb-0">Đăng nhập <%=title%></p></div>
<% if ("1".equals(request.getParameter("error"))) { %><div class="alert alert-danger">Tên đăng nhập hoặc mật khẩu không chính xác.</div><% } %>
<form method="post" action="<%=request.getContextPath()%>/LoginServlet">
<input type="hidden" name="role" value="<%=role%>">
<div class="mb-3"><label class="form-label">Tên đăng nhập</label><input class="form-control form-control-lg" name="username" required autocomplete="username"></div>
<div class="mb-4"><label class="form-label">Mật khẩu</label><input class="form-control form-control-lg" type="password" name="password" required autocomplete="current-password"></div>
<button class="btn btn-main btn-lg w-100" type="submit">Đăng nhập</button>
</form>
</div></div></div></body></html>
