<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%
    String ctx = request.getContextPath();
%>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>CineMan - Hệ thống đặt vé xem phim</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body{background:#f4f6fb;color:#172033}.hero{background:linear-gradient(135deg,#172033,#315ce8);color:white;border-radius:24px}
.btn-main{background:#315ce8;color:white}.btn-main:hover{background:#2449c5;color:white}.choice{border:0;border-radius:18px;box-shadow:0 8px 28px #17203312}
</style>
</head>
<body>
<nav class="navbar bg-white shadow-sm"><div class="container"><a class="navbar-brand fw-bold" href="<%=ctx%>/index.jsp">CineMan</a><span class="text-secondary small">Cinema Management</span></div></nav>
<main class="container py-5">
<section class="hero p-5 mb-5">
    <div class="row align-items-center"><div class="col-lg-8">
        <span class="badge bg-light text-primary mb-3">CINEMAN ONLINE</span>
        <h1 class="display-5 fw-bold">Trải nghiệm điện ảnh<br>theo cách của bạn</h1>
        <p class="lead mb-0">Hệ thống minh họa quản lý phim và đặt vé trực tuyến.</p>
    </div><div class="col-lg-4 text-lg-end mt-4 mt-lg-0"><span class="display-1">🎬</span></div></div>
</section>
<div class="text-center mb-4"><h2 class="fw-bold">Bạn muốn tiếp tục với vai trò nào?</h2><p class="text-secondary">Chọn đúng tài khoản để đăng nhập.</p></div>
<div class="row g-4 justify-content-center">
<div class="col-md-5"><div class="card choice h-100"><div class="card-body p-4">
<div class="fs-1 mb-3">🛠️</div><h4 class="fw-bold">Manager</h4><p class="text-secondary">Quản lý và bổ sung phim vào hệ thống.</p>
<a class="btn btn-main w-100" href="<%=ctx%>/login.jsp?role=manager">Đăng nhập Manager</a>
</div></div></div>
<div class="col-md-5"><div class="card choice h-100"><div class="card-body p-4">
<div class="fs-1 mb-3">🎟️</div><h4 class="fw-bold">Customer</h4><p class="text-secondary">Xem danh sách phim, chọn suất chiếu và đặt vé.</p>
<a class="btn btn-main w-100" href="<%=ctx%>/login.jsp?role=customer">Đăng nhập Customer</a>
</div></div></div>
</div>
</main>
<footer class="text-center text-secondary small py-4">CineMan · Java Web Project</footer>
</body></html>
