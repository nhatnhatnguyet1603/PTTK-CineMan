
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%
    String contextPath = request.getContextPath();
    String fullName = (String) session.getAttribute("fullName");

    if (fullName == null) {
        fullName = "Customer";
    }
%>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Customer Main Menu - CineMan</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css"
          rel="stylesheet">

    <style>
        body {
            background: #f4f6fb;
            font-family: Arial, sans-serif;
        }

        .navbar {
            background: #172033;
        }

        .main-card {
            max-width: 850px;
            margin: 90px auto;
            background: white;
            border-radius: 16px;
            padding: 45px;
            box-shadow: 0 5px 25px rgba(0,0,0,.06);
        }

        .menu-card {
            border: 1px solid #e5e9f2;
            border-radius: 12px;
            padding: 28px;
            transition: .2s;
        }

        .menu-card:hover {
            border-color: #315ce8;
            transform: translateY(-3px);
        }

        .btn-primary {
            background: #315ce8;
            border-color: #315ce8;
        }
    </style>
</head>

<body>

<nav class="navbar navbar-dark">
    <div class="container">
        <span class="navbar-brand fw-bold">CineMan</span>

        <div class="text-white">
            Xin chào, <strong><%= fullName %></strong>
        </div>
    </div>
</nav>

<div class="container">

    <div class="main-card">

        <div class="text-center mb-5">
            <h2 class="fw-bold">Customer Main Menu</h2>
            <p class="text-secondary">
                Chào mừng bạn đến với hệ thống đặt vé CineMan.
            </p>
        </div>

        <div class="menu-card text-center">

            <h4 class="fw-bold mb-3">
                Mua vé trực tuyến
            </h4>

            <p class="text-secondary">
                Xem danh sách phim, chọn suất chiếu và ghế ngồi
                để đặt vé trực tuyến.
            </p>

            <a href="<%= contextPath %>/BuyTicketMenu8"
               class="btn btn-primary px-4">
                Mua vé ngay
            </a>

        </div>

        <div class="text-center mt-4">
            <a href="<%= contextPath %>/logout"
               class="text-decoration-none text-secondary">
                Đăng xuất
            </a>
        </div>

    </div>

</div>

</body>
</html>
