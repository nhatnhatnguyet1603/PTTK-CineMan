
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%
    String contextPath = request.getContextPath();
%>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Buy Ticket Menu - CineMan</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css"
          rel="stylesheet">

    <style>
        body {
            background: #f4f6fb;
            font-family: Arial, sans-serif;
        }

        .navbar {
            background: #172033;
        }

        .menu-container {
            max-width: 800px;
            margin: 90px auto;
        }

        .menu-card {
            background: white;
            border-radius: 16px;
            padding: 45px;
            box-shadow: 0 5px 25px rgba(0,0,0,.06);
        }

        .option-card {
            border: 1px solid #e5e9f2;
            border-radius: 12px;
            padding: 25px;
        }

        .btn-primary {
            background: #315ce8;
            border-color: #315ce8;
        }
    </style>
</head>

<body>

<nav class="navbar navbar-dark">
    <div class="container">
        <span class="navbar-brand fw-bold">CineMan</span>
        <a href="<%= contextPath %>/CustomerMainMenu8"
           class="text-white text-decoration-none">
            Quay lại
        </a>
    </div>
</nav>

<div class="container">

    <div class="menu-container">

        <div class="menu-card">

            <h2 class="fw-bold text-center mb-2">
                Buy Ticket Menu
            </h2>

            <p class="text-secondary text-center mb-5">
                Chọn hình thức mua vé bạn muốn thực hiện.
            </p>

            <div class="option-card text-center">

                <h4 class="fw-bold mb-3">
                    Mua vé trực tuyến
                </h4>

                <p class="text-secondary">
                    Chọn phim, suất chiếu, ghế ngồi
                    và xác nhận đặt vé.
                </p>

                <a href="<%= contextPath %>/BuyTicketOnlineController8"
                   class="btn btn-primary px-4">
                    Chọn phim
                </a>

            </div>

            <div class="text-center mt-4">
                <a href="<%= contextPath %>/CustomerMainMenu8"
                   class="text-secondary text-decoration-none">
                    Quay lại Customer Main Menu
                </a>
            </div>

        </div>

    </div>

</div>

</body>
</html>
