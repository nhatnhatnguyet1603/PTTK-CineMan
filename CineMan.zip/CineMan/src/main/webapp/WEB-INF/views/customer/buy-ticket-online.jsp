
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.List" %>
<%@ page import="java.text.NumberFormat" %>
<%@ page import="java.util.Locale" %>
<%@ page import="cineman.model.Movie8" %>
<%@ page import="cineman.model.Showtime8" %>
<%@ page import="cineman.model.Seat8" %>
<%@ page import="cineman.model.Booking8" %>
<%@ page import="cineman.model.Ticket8" %>
<%@ page import="cineman.model.Payment8" %>
<%@ page import="cineman.model.Invoice8" %>

<%
    String contextPath = request.getContextPath();

    List<Movie8> movieList =
            (List<Movie8>) request.getAttribute("movieList");

    List<Showtime8> showtimeList =
            (List<Showtime8>) request.getAttribute("showtimeList");

    List<Seat8> seatList =
            (List<Seat8>) request.getAttribute("seatList");

    String selectedMovieId =
            (String) request.getAttribute("selectedMovieId");

    String selectedShowtimeId =
            (String) request.getAttribute("selectedShowtimeId");

    if (selectedMovieId == null) {
        selectedMovieId = request.getParameter("movieId");
    }

    if (selectedShowtimeId == null) {
        selectedShowtimeId = request.getParameter("showtimeId");
    }

    String errorMessage =
            (String) request.getAttribute("errorMessage");

    String successMessage =
            (String) request.getAttribute("successMessage");

    Boolean purchaseSuccessObj =
            (Boolean) request.getAttribute("purchaseSuccess");

    boolean purchaseSuccess =
            purchaseSuccessObj != null && purchaseSuccessObj;

    Booking8 booking =
            (Booking8) request.getAttribute("booking");

    List<Ticket8> ticketList =
            (List<Ticket8>) request.getAttribute("ticketList");

    Payment8 payment =
            (Payment8) request.getAttribute("payment");

    Invoice8 invoice =
            (Invoice8) request.getAttribute("invoice");

    Movie8 selectedMovie =
            (Movie8) request.getAttribute("selectedMovie");

    Showtime8 selectedShowtime =
            (Showtime8) request.getAttribute("selectedShowtime");

    List<Seat8> selectedSeats =
            (List<Seat8>) request.getAttribute("selectedSeats");

    NumberFormat currency =
            NumberFormat.getNumberInstance(new Locale("vi", "VN"));
%>

<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Mua vé trực tuyến - CineMan</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css"
          rel="stylesheet">

    <style>
        body {
            background: #f4f6fb;
            font-family: Arial, sans-serif;
            color: #172033;
        }

        .navbar {
            background: #172033;
        }

        .page-container {
            max-width: 1100px;
            margin: 35px auto;
        }

        .section-card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            margin-bottom: 22px;
            box-shadow: 0 3px 15px rgba(0,0,0,.04);
        }

        .section-title {
            font-weight: 700;
            margin-bottom: 20px;
        }

        .movie-card {
            border: 1px solid #e5e9f2;
            border-radius: 10px;
            padding: 18px;
            height: 100%;
            transition: .2s;
        }

        .movie-card:hover {
            border-color: #315ce8;
            box-shadow: 0 3px 12px rgba(49,92,232,.08);
        }

        .btn-primary {
            background: #315ce8;
            border-color: #315ce8;
        }

        .btn-primary:hover {
            background: #2449c7;
            border-color: #2449c7;
        }

        /* =================================================
           SO DO GHE - 10 GHE MOI HANG
           TONG 3 HANG: A, B, C
        ================================================= */

        .seat-grid {
            display: grid;
            grid-template-columns: repeat(10, 65px);
            justify-content: center;
            gap: 12px;
            margin: 0 auto 25px;
            max-width: 100%;
        }

        .seat-option {
            width: 65px;
        }

        .seat-option input {
            display: none;
        }

        .seat-option label {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 65px;
            height: 45px;
            padding: 0;
            border: 1px solid #ced4da;
            border-radius: 7px;
            text-align: center;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            background: #f8f9fa;
            color: #172033;
            transition: .2s;
        }

        /* Ghe dang chon */
        .seat-option input:checked + label {
            background: #315ce8;
            color: white;
            border-color: #315ce8;
        }

        /* Hieu ung khi di chuot */
        .seat-option label:hover {
            border-color: #315ce8;
            background: #eef2ff;
        }

        .seat-option input:checked + label:hover {
            background: #2449c7;
            color: white;
        }

        /* Chu thich ghe */
        .seat-legend {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 22px;
            margin-bottom: 25px;
        }

        .legend-item {
            display: flex;
            align-items: center;
            gap: 7px;
            font-size: 13px;
            color: #6c757d;
        }

        .legend-box {
            width: 20px;
            height: 20px;
            border-radius: 5px;
            border: 1px solid #ced4da;
            background: #f8f9fa;
        }

        .legend-box.selected {
            background: #315ce8;
            border-color: #315ce8;
        }

        .legend-box.unavailable {
            background: #dee2e6;
            border-color: #ced4da;
        }

        /* Man hinh */
        .screen-container {
            max-width: 750px;
            margin: 0 auto 35px;
        }

        .screen {
            height: 9px;
            background: #315ce8;
            border-radius: 50% 50% 5px 5px;
            box-shadow: 0 5px 15px rgba(49,92,232,.2);
        }

        .screen-text {
            font-size: 12px;
            color: #8490a5;
            text-align: center;
            margin-top: 12px;
            letter-spacing: 3px;
            font-weight: 600;
        }

        .price {
            color: #315ce8;
            font-weight: 700;
        }

        .success-icon {
            width: 65px;
            height: 65px;
            border-radius: 50%;
            background: #d1e7dd;
            color: #198754;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            margin: 0 auto 15px;
        }

        .ticket-card {
            border: 1px dashed #315ce8;
            border-radius: 10px;
            padding: 18px;
            background: #f8faff;
        }

        .info-label {
            color: #6c757d;
            font-size: 13px;
            margin-bottom: 4px;
        }

        .info-value {
            font-weight: 600;
            word-break: break-word;
        }

        .invoice-total {
            background: #f4f6fb;
            border-radius: 10px;
            padding: 20px;
        }

        .final-price {
            color: #315ce8;
            font-size: 23px;
            font-weight: 700;
        }

        /* Responsive */
        @media (max-width: 800px) {

            .page-container {
                margin: 20px auto;
            }

            .section-card {
                padding: 18px;
            }

            .seat-grid {
                grid-template-columns: repeat(10, minmax(0, 1fr));
                gap: 6px;
                width: 100%;
            }

            .seat-option {
                width: 100%;
                min-width: 0;
            }

            .seat-option label {
                width: 100%;
                height: 38px;
                font-size: 12px;
            }
        }

        @media (max-width: 400px) {

            .seat-grid {
                gap: 3px;
            }

            .seat-option label {
                height: 32px;
                font-size: 10px;
            }
        }
    </style>
</head>

<body>

<nav class="navbar navbar-dark">
    <div class="container">
        <span class="navbar-brand fw-bold">CineMan</span>

        <a href="<%= contextPath %>/BuyTicketMenu8"
           class="text-white text-decoration-none">
            Quay lại
        </a>
    </div>
</nav>

<div class="container page-container">

    <h2 class="fw-bold mb-4">Mua vé trực tuyến</h2>

    <% if (errorMessage != null) { %>
        <div class="alert alert-danger">
            <%= errorMessage %>
        </div>
    <% } %>

    <% if (successMessage != null && !purchaseSuccess) { %>
        <div class="alert alert-success">
            <%= successMessage %>
        </div>
    <% } %>

    <!-- KET QUA MUA VE THANH CONG -->

    <% if (purchaseSuccess && booking != null) { %>

        <div class="section-card text-center">

            <div class="success-icon">
                &#10003;
            </div>

            <h3 class="fw-bold text-success">
                Mua vé thành công!
            </h3>

            <p class="text-secondary mb-0">
                Giao dịch đặt vé của bạn đã được ghi nhận trên hệ thống CineMan.
            </p>

        </div>

        <!-- THONG TIN BOOKING -->

        <div class="section-card">

            <h5 class="section-title">
                1. Thông tin đặt vé
            </h5>

            <div class="row g-3">

                <div class="col-md-6">
                    <div class="info-label">Mã đặt vé</div>
                    <div class="info-value">
                        <%= booking.getBookingId() %>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="info-label">Thời gian đặt</div>
                    <div class="info-value">
                        <%= booking.getBookingTime() %>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="info-label">Tên phim</div>
                    <div class="info-value">
                        <%= selectedMovie != null
                                ? selectedMovie.getMovieName()
                                : "Không có dữ liệu" %>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="info-label">Suất chiếu</div>
                    <div class="info-value">
                        <%= selectedShowtime != null
                                ? selectedShowtime.getStartTime()
                                : "Không có dữ liệu" %>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="info-label">Phòng chiếu</div>
                    <div class="info-value">
                        <%= selectedShowtime != null
                                ? selectedShowtime.getRoomId()
                                : "Không có dữ liệu" %>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="info-label">Trạng thái booking</div>
                    <div>
                        <span class="badge bg-success">
                            <%= booking.getBookingStatus() %>
                        </span>
                    </div>
                </div>

            </div>

        </div>

        <!-- DANH SACH VE -->

        <div class="section-card">

            <h5 class="section-title">
                2. Danh sách vé
            </h5>

            <% if (ticketList != null && !ticketList.isEmpty()) { %>

                <div class="row g-3">

                    <% for (Ticket8 ticket : ticketList) { %>

                        <div class="col-md-6">

                            <div class="ticket-card">

                                <div class="d-flex justify-content-between align-items-center mb-3">

                                    <strong class="text-primary">
                                        VÉ ĐIỆN TỬ
                                    </strong>

                                    <span class="badge bg-success">
                                        <%= ticket.getTicketStatus() %>
                                    </span>

                                </div>

                                <div class="row g-3">

                                    <div class="col-6">
                                        <div class="info-label">Mã vé</div>
                                        <div class="info-value">
                                            <%= ticket.getTicketId() %>
                                        </div>
                                    </div>

                                    <div class="col-6">
                                        <div class="info-label">Mã ghế</div>
                                        <div class="info-value">
                                            <%= ticket.getSeatId() %>
                                        </div>
                                    </div>

                                    <div class="col-6">
                                        <div class="info-label">Số ghế</div>
                                        <div class="info-value">
                                            <%
                                                String seatNumber = ticket.getSeatId();

                                                if (selectedSeats != null) {
                                                    for (Seat8 seat : selectedSeats) {
                                                        if (seat.getSeatId().equals(ticket.getSeatId())) {
                                                            seatNumber = seat.getSeatNumber();
                                                            break;
                                                        }
                                                    }
                                                }
                                            %>
                                            <%= seatNumber %>
                                        </div>
                                    </div>

                                    <div class="col-6">
                                        <div class="info-label">Giá vé</div>
                                        <div class="info-value price">
                                            <%= currency.format(ticket.getTicketPrice()) %> VNĐ
                                        </div>
                                    </div>

                                </div>

                                <hr>

                                <div class="small text-secondary">
                                    Mã đặt vé:
                                    <strong><%= ticket.getBookingId() %></strong>
                                </div>

                            </div>

                        </div>

                    <% } %>

                </div>

            <% } else { %>

                <div class="alert alert-warning mb-0">
                    Không tìm thấy thông tin vé trong kết quả trả về.
                </div>

            <% } %>

        </div>

        <!-- THONG TIN THANH TOAN -->

        <div class="section-card">

            <h5 class="section-title">
                3. Thông tin thanh toán
            </h5>

            <% if (payment != null) { %>

                <div class="row g-3">

                    <div class="col-md-6">
                        <div class="info-label">Mã thanh toán</div>
                        <div class="info-value">
                            <%= payment.getPaymentId() %>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="info-label">Thời gian thanh toán</div>
                        <div class="info-value">
                            <%= payment.getPaymentTime() %>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="info-label">Phương thức thanh toán</div>
                        <div class="info-value">
                            <%= payment.getPaymentMethod() %>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="info-label">Trạng thái thanh toán</div>
                        <span class="badge bg-success">
                            <%= payment.getPaymentStatus() %>
                        </span>
                    </div>

                    <div class="col-md-6">
                        <div class="info-label">Số tiền thanh toán</div>
                        <div class="info-value price">
                            <%= currency.format(payment.getAmount()) %> VNĐ
                        </div>
                    </div>

                </div>

            <% } else { %>

                <div class="alert alert-warning mb-0">
                    Không tìm thấy thông tin thanh toán.
                </div>

            <% } %>

        </div>

        <!-- HOA DON -->

        <div class="section-card">

            <h5 class="section-title">
                4. Hóa đơn thanh toán
            </h5>

            <% if (invoice != null) { %>

                <div class="border rounded p-4">

                    <div class="text-center mb-4">

                        <h4 class="fw-bold">
                            CINEMAN
                        </h4>

                        <p class="text-secondary mb-1">
                            HÓA ĐƠN THANH TOÁN VÉ XEM PHIM
                        </p>

                        <span class="text-secondary small">
                            Mã hóa đơn:
                            <strong><%= invoice.getInvoiceId() %></strong>
                        </span>

                    </div>

                    <hr>

                    <div class="row mb-3">

                        <div class="col-md-6">
                            <div class="info-label">Mã đặt vé</div>
                            <div class="info-value">
                                <%= invoice.getBookingId() %>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="info-label">Ngày lập hóa đơn</div>
                            <div class="info-value">
                                <%= invoice.getIssueDate() %>
                            </div>
                        </div>

                    </div>

                    <hr>

                    <div class="invoice-total">

                        <div class="d-flex justify-content-between mb-3">
                            <span>Tổng tiền vé</span>

                            <strong>
                                <%= currency.format(invoice.getTotalAmount()) %> VNĐ
                            </strong>
                        </div>

                        <div class="d-flex justify-content-between mb-3">
                            <span>Giảm giá thành viên</span>

                            <strong class="text-success">
                                - <%= currency.format(invoice.getDiscount()) %> VNĐ
                            </strong>
                        </div>

                        <hr>

                        <div class="d-flex justify-content-between align-items-center">

                            <strong>THÀNH TIỀN</strong>

                            <span class="final-price">
                                <%= currency.format(invoice.getFinalAmount()) %> VNĐ
                            </span>

                        </div>

                    </div>

                    <div class="text-center mt-4">

                        <p class="text-secondary small mb-0">
                            Cảm ơn bạn đã sử dụng dịch vụ của CineMan!
                        </p>

                    </div>

                </div>

            <% } else { %>

                <div class="alert alert-warning mb-0">
                    Không tìm thấy hóa đơn thanh toán.
                </div>

            <% } %>

        </div>

        <div class="text-center mb-5">

            <a href="<%= contextPath %>/BuyTicketMenu8"
               class="btn btn-primary px-4 py-2">
                Quay về trang đặt vé
            </a>

        </div>

    <% } else { %>

        <!-- PHAN 1: DANH SACH PHIM -->

        <div class="section-card">

            <h5 class="section-title">1. Chọn phim</h5>

            <div class="row g-3">

                <% if (movieList != null && !movieList.isEmpty()) { %>

                    <% for (Movie8 movie : movieList) { %>

                        <div class="col-md-4">

                            <div class="movie-card">

                                <h6 class="fw-bold">
                                    <%= movie.getMovieName() %>
                                </h6>

                                <p class="text-secondary mb-1">
                                    Thể loại:
                                    <%= movie.getGenre() == null
                                            ? "Chưa cập nhật"
                                            : movie.getGenre() %>
                                </p>

                                <p class="text-secondary mb-3">
                                    Thời lượng:
                                    <%= movie.getDuration() %> phút
                                </p>

                                <a class="btn btn-primary btn-sm"
                                   href="<%= contextPath %>/BuyTicketOnlineController8?action=showtimes&movieId=<%= java.net.URLEncoder.encode(movie.getMovieId(), "UTF-8") %>">
                                    Chọn phim
                                </a>

                            </div>

                        </div>

                    <% } %>

                <% } else { %>

                    <div class="col-12">
                        <p class="text-secondary">
                            Hiện chưa có phim phù hợp để đặt vé.
                        </p>
                    </div>

                <% } %>

            </div>

        </div>

        <!-- PHAN 2: SUAT CHIEU -->

        <% if (showtimeList != null) { %>

            <div class="section-card">

                <h5 class="section-title">2. Chọn suất chiếu</h5>

                <% if (!showtimeList.isEmpty()) { %>

                    <div class="list-group">

                        <% for (Showtime8 showtime : showtimeList) { %>

                            <a class="list-group-item list-group-item-action
                                      d-flex justify-content-between align-items-center"
                               href="<%= contextPath %>/BuyTicketOnlineController8?action=seats&movieId=<%= java.net.URLEncoder.encode(showtime.getMovieId(), "UTF-8") %>&showtimeId=<%= java.net.URLEncoder.encode(showtime.getShowtimeId(), "UTF-8") %>">

                                <div>

                                    <strong>
                                        <%= showtime.getStartTime() %>
                                    </strong>

                                    <div class="small text-secondary">
                                        Phòng: <%= showtime.getRoomId() %>
                                    </div>

                                </div>

                                <span class="price">
                                    <%= currency.format(showtime.getTicketPrice()) %> VNĐ
                                </span>

                            </a>

                        <% } %>

                    </div>

                <% } else { %>

                    <p class="text-secondary">
                        Phim hiện chưa có suất chiếu phù hợp.
                    </p>

                <% } %>

            </div>

        <% } %>

        <!-- PHAN 3: CHON GHE VA XAC NHAN -->

        <% if (seatList != null) { %>

            <div class="section-card">

                <h5 class="section-title">3. Chọn ghế</h5>

                <% if (!seatList.isEmpty()) { %>

                    <div class="screen-container">

                        <div class="screen"></div>

                        <div class="screen-text">
                            MÀN HÌNH
                        </div>

                    </div>

                    <div class="seat-legend">

                        <div class="legend-item">
                            <span class="legend-box"></span>
                            Ghế trống
                        </div>

                        <div class="legend-item">
                            <span class="legend-box selected"></span>
                            Ghế đang chọn
                        </div>

                        <div class="legend-item">
                            <span class="legend-box unavailable"></span>
                            Ghế đã đặt
                        </div>

                    </div>

                    <form method="post"
                          action="<%= contextPath %>/BuyTicketOnlineController8">

                        <input type="hidden"
                               name="action"
                               value="confirmPurchase">

                        <input type="hidden"
                               name="movieId"
                               value="<%= selectedMovieId == null ? "" : selectedMovieId %>">

                        <input type="hidden"
                               name="showtimeId"
                               value="<%= selectedShowtimeId == null ? "" : selectedShowtimeId %>">

                        <div class="seat-grid">

                            <% for (Seat8 seat : seatList) { %>

                                <div class="seat-option">

                                    <input type="checkbox"
                                           id="seat_<%= seat.getSeatId() %>"
                                           name="seatIds"
                                           value="<%= seat.getSeatId() %>">

                                    <label for="seat_<%= seat.getSeatId() %>">
                                        <%= seat.getSeatNumber() %>
                                    </label>

                                </div>

                            <% } %>

                        </div>

                        <hr>

                        <h5 class="section-title">
                            4. Mã thành viên
                        </h5>

                        <div class="mb-4">

                            <label class="form-label">
                                Membership Code (Không bắt buộc)
                            </label>

                            <input type="text"
                                   name="membershipCode"
                                   class="form-control"
                                   placeholder="Nhập mã thành viên nếu có">

                            <div class="form-text">
                                Mã thành viên hợp lệ được giảm 5% tổng tiền vé.
                            </div>

                        </div>

                        <h5 class="section-title">
                            5. Phương thức thanh toán
                        </h5>

                        <select name="paymentMethod"
                                class="form-select mb-4"
                                required>

                            <option value="">-- Chọn phương thức --</option>
                            <option value="CASH">Tiền mặt (mô phỏng)</option>
                            <option value="BANKING">Chuyển khoản (mô phỏng)</option>

                        </select>

                        <button type="submit"
                                class="btn btn-primary px-4">
                            Xác nhận mua vé
                        </button>

                    </form>

                <% } else { %>

                    <p class="text-secondary">
                        Không còn ghế trống trong suất chiếu này.
                    </p>

                <% } %>

            </div>

        <% } %>

    <% } %>

</div>

</body>
</html>
