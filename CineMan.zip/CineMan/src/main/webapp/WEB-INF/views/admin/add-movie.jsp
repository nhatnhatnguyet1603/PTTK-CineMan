<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.List" %>
<%@ page import="cineman.model.Movie8" %>

<%
if (session.getAttribute("employeeId") == null
        || !"manager".equalsIgnoreCase(
                String.valueOf(session.getAttribute("userRole")))) {

    response.sendRedirect(request.getContextPath() + "/login.jsp");
    return;
}

    List<Movie8> movieList =
            (List<Movie8>) request.getAttribute("movieList");

    Movie8 movie =
            (Movie8) request.getAttribute("movie");

    String outResult =
            (String) request.getAttribute("outResult");

    String resultType =
            (String) request.getAttribute("resultType");

    if (movieList == null) {
        movieList = new java.util.ArrayList<>();
    }

    String inMovieName = movie == null ? "" : movie.getMovieName();
    String inGenre = movie == null ? "" : movie.getGenre();

    String inDuration = movie == null
            ? ""
            : String.valueOf(movie.getDuration());

    String inDescription =
            movie == null ? "" : movie.getDescription();

    String inStartDate = movie == null
            || movie.getStartDate() == null
            ? ""
            : movie.getStartDate().toString();

    String inEndDate = movie == null
            || movie.getEndDate() == null
            ? ""
            : movie.getEndDate().toString();
%>

<!DOCTYPE html>
<html lang="vi">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Add Movie - CineMan</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css"
          rel="stylesheet">

    <style>

        body {
            background-color: #f4f6fa;
            color: #172033;
        }

        .navbar {
            background-color: #172033;
        }

        .main-card {
            border: none;
            border-radius: 14px;
        }

        .btn-primary {
            background-color: #315CE8;
            border-color: #315CE8;
        }

        .form-label {
            font-weight: 600;
        }

        .table thead {
            background-color: #172033;
            color: white;
        }

    </style>

</head>

<body>

<nav class="navbar navbar-dark px-4 py-3">

    <span class="navbar-brand fw-bold">
        CineMan
    </span>

    <span class="text-white">
        Chức năng thêm phim
    </span>

</nav>

<div class="container py-4">

    <div class="mb-3">

        <a href="<%= request.getContextPath() %>/MovieManageMenu8"
           class="text-decoration-none">
            ← Quay lại quản lý phim
        </a>

    </div>

    <h3 class="fw-bold mb-1">
        Thêm phim mới
    </h3>

    <p class="text-secondary mb-4">
        Nhập thông tin phim cần thêm vào hệ thống CineMan.
    </p>

    <% if (outResult != null) { %>

        <div class="alert alert-<%= resultType == null ? "info" : resultType %> alert-dismissible fade show"
             role="alert">

            <%= outResult %>

            <button type="button"
                    class="btn-close"
                    data-bs-dismiss="alert">
            </button>

        </div>

    <% } %>

    <!-- Biểu mẫu nhập thông tin phim -->
    <div class="card main-card shadow-sm mb-4">

        <div class="card-body p-4">

            <form action="<%= request.getContextPath() %>/AddMovieController8"
                  method="post">

                <div class="row g-3">

                    <div class="col-md-6">

                        <label for="inMovieName"
                               class="form-label">
                            Tên phim
                        </label>

                        <input type="text"
                               class="form-control"
                               id="inMovieName"
                               name="inMovieName"
                               value="<%= inMovieName == null ? "" : inMovieName %>"
                               maxlength="200"
                               required>

                    </div>

                    <div class="col-md-6">

                        <label for="inGenre"
                               class="form-label">
                            Thể loại
                        </label>

                        <input type="text"
                               class="form-control"
                               id="inGenre"
                               name="inGenre"
                               value="<%= inGenre == null ? "" : inGenre %>"
                               maxlength="100"
                               required>

                    </div>

                    <div class="col-md-6">

                        <label for="inDuration"
                               class="form-label">
                            Thời lượng (phút)
                        </label>

                        <input type="number"
                               class="form-control"
                               id="inDuration"
                               name="inDuration"
                               value="<%= inDuration %>"
                               min="1"
                               required>

                    </div>

                    <div class="col-md-6">

                        <label for="inStartDate"
                               class="form-label">
                            Ngày bắt đầu chiếu
                        </label>

                        <input type="date"
                               class="form-control"
                               id="inStartDate"
                               name="inStartDate"
                               value="<%= inStartDate %>"
                               required>

                    </div>

                    <div class="col-md-6">

                        <label for="inEndDate"
                               class="form-label">
                            Ngày kết thúc chiếu
                        </label>

                        <input type="date"
                               class="form-control"
                               id="inEndDate"
                               name="inEndDate"
                               value="<%= inEndDate %>"
                               required>

                    </div>

                    <div class="col-12">

                        <label for="inDescription"
                               class="form-label">
                            Mô tả phim
                        </label>

                        <textarea class="form-control"
                                  id="inDescription"
                                  name="inDescription"
                                  rows="4"
                                  required><%= inDescription == null ? "" : inDescription %></textarea>

                    </div>

                </div>

                <div class="mt-4">

                    <button type="submit"
                            name="subAdd"
                            value="1"
                            class="btn btn-primary px-4">
                        Thêm phim
                    </button>

                    <button type="reset"
                            class="btn btn-outline-secondary ms-2">
                        Nhập lại
                    </button>

                </div>

            </form>

        </div>

    </div>

    <!-- Danh sách phim sau khi cập nhật -->
    <div class="card main-card shadow-sm">

        <div class="card-body p-4">

            <div class="d-flex justify-content-between align-items-center mb-3">

                <h5 class="fw-bold mb-0">
                    Danh sách phim
                </h5>

                <span class="badge text-bg-primary">
                    <%= movieList.size() %> phim
                </span>

            </div>

            <div class="table-responsive">

                <table class="table table-bordered table-hover align-middle">

                    <thead>
                        <tr>
                            <th>STT</th>
                            <th>Mã phim</th>
                            <th>Tên phim</th>
                            <th>Thể loại</th>
                            <th>Thời lượng</th>
                            <th>Ngày bắt đầu</th>
                            <th>Ngày kết thúc</th>
                            <th>Trạng thái</th>
                        </tr>
                    </thead>

                    <tbody>

                    <% if (movieList.isEmpty()) { %>

                        <tr>
                            <td colspan="8"
                                class="text-center text-secondary py-4">
                                Chưa có dữ liệu phim.
                            </td>
                        </tr>

                    <% } else { %>

                        <% int index = 1; %>

                        <% for (Movie8 item : movieList) { %>

                            <tr>

                                <td><%= index++ %></td>

                                <td><%= item.getMovieId() %></td>

                                <td><%= item.getMovieName() %></td>

                                <td><%= item.getGenre() %></td>

                                <td><%= item.getDuration() %> phút</td>

                                <td><%= item.getStartDate() %></td>

                                <td><%= item.getEndDate() %></td>

                                <td>
                                    <span class="badge text-bg-success">
                                        <%= item.getStatus() %>
                                    </span>
                                </td>

                            </tr>

                        <% } %>

                    <% } %>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js">
</script>

</body>
</html>