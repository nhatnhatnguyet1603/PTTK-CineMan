<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>

<%
    if (session.getAttribute("employeeId") == null
            && session.getAttribute("managerId") == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Movie Management - CineMan</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css"
          rel="stylesheet">

    <style>
        body {
            background-color: #f4f6fa;
            color: #172033;
        }

        .navbar {
            background-color: #172033;
        }

        .menu-card {
            border: none;
            border-radius: 14px;
        }

        .btn-primary {
            background-color: #315CE8;
            border-color: #315CE8;
        }
    </style>
</head>

<body>

<nav class="navbar navbar-dark px-4 py-3">
    <span class="navbar-brand fw-bold">CineMan</span>
    <span class="text-white">Quản lý phim</span>
</nav>

<div class="container py-5">

    <div class="mb-4">
        <a href="<%= request.getContextPath() %>/WEB-INF/views/admin/manager-main-menu.jsp"
           class="text-decoration-none">
            ← Quay lại
        </a>
    </div>

    <h3 class="fw-bold mb-2">Quản lý phim</h3>

    <p class="text-secondary mb-4">
        Chọn chức năng quản lý phim.
    </p>

    <div class="row g-4">

        <div class="col-md-5 col-lg-4">

            <div class="card menu-card shadow-sm h-100">
                <div class="card-body p-4">

                    <h5 class="fw-bold">Thêm phim</h5>

                    <p class="text-secondary">
                        Thêm thông tin phim mới vào cơ sở dữ liệu.
                    </p>

                    <a href="<%= request.getContextPath() %>/AddMovieController8"
                       class="btn btn-primary w-100">
                        Thêm phim
                    </a>

                </div>
            </div>

        </div>

    </div>

</div>

</body>
</html>